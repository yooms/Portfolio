#include "stdafx.h"
#include <hash_map>
#include <functional>
#include <deque>
#include "FSM_BaseState.hpp"
#include "FSM_Manager.hpp"
#include "FSM_Actor.h"
#include "FSM_Enemy.h"
#include "FSM_ActorBridge.hpp"
#include "FSM_EnemyBridge.hpp"
#include "FSM_Enemy_Msg.h"
#include "FSM_Enemy_State.h"
#include "..\EventManager\EventPlayer.h"
#include "..\Util\Util_Funcs.hpp"

namespace ENEMY
{
	struct ATTACK_DATA
	{
		ATTACK_DATA() : skill_id(0),skill_motion(0),
			skill_lv(0)
		{
			_asm nop
		}
		~ATTACK_DATA()
		{
			_asm nop;
		}
		unsigned int skill_id;
		unsigned int skill_motion;
		unsigned char skill_lv;
		unsigned int target_id;
	};

	struct JUMP_DATA
	{
		JUMP_DATA()
		{
			jump_state = FSM_Enemy::JS_NONE;
			jump_angle = 0.f;
			jump_start_time = 0.f;
			jump_top_time = 0.f;
			jump_speed = 0.f;
			jump_height = 0.f;
			jump_org_height = 0.f;
			ZeroMemory(&jump_dir, sizeof(hkvVec3));
			ZeroMemory(&jump_landingPos, sizeof(hkvVec3));
		}
		FSM_Enemy::JUMP_STATE jump_state;				// ���� ����
		float jump_angle;								// ���� ����
		float jump_start_time;							// ���� ���� �ð�
		float jump_top_time;							// ���� ü�� �ð�
		float jump_speed;								// ���� �ӵ�
		float jump_height;								// ���� ����
		float jump_org_height;							// ���� ���� ����
		hkvVec3 jump_dir;								// ���� ����
		hkvVec3 jump_landingPos;						// ���� ���� ��ġ
	};
}

struct FSM_Enemy_Pimpl
{
	FSM_Manager<FSM_Enemy>* fsm_mgr;
	FSM_EnemyBridge bridge;
	std::deque<std::shared_ptr<ENEMY::ATTACK_DATA>> atk_infos;
	FSM_Enemy::STAND_STATE	stand_state;
	ENEMY::JUMP_DATA jump_info;
	unsigned int _AdventAniID;
	bool _AdventFlag;

	FSM_Enemy_Pimpl()
		: fsm_mgr(nullptr)
		, stand_state(FSM_Enemy::ST_IDLE)
		, _AdventAniID(0)
		, _AdventFlag(false)
	{
	};
};

// ������
FSM_Enemy::FSM_Enemy()
	: _pimpl(new FSM_Enemy_Pimpl)
{
}

// �Ҹ���
FSM_Enemy::~FSM_Enemy()
{
	V_SAFE_DELETE(_pimpl->fsm_mgr);
	V_SAFE_DELETE(_pimpl);
}

// �ʱ�ȭ ó��
void FSM_Enemy::initFSM()
{
	// FSM �Ŵ��� ����
	if (_pimpl->fsm_mgr == nullptr)
	{
		_pimpl->fsm_mgr = new FSM_Manager<FSM_Enemy>(this);
		if (isDead())
		{
			_pimpl->fsm_mgr->change(FSM_Enemy_Die::state());
			getEventPlayer()->gotoAniEnd();
		}
		else if(isSpecialAdvent())
		{
			_pimpl->fsm_mgr->change(FSM_Enemy_Ambush::state());
		}
		else
		{
			_pimpl->fsm_mgr->change(FSM_Enemy_Stand::state());
		}
		_pimpl->fsm_mgr->setChangeFunctor(_pimpl->bridge.fn_changedFSM);
	}

	connectTimingProcessor();
}

// ������Ʈ ó��
void FSM_Enemy::updateFSM(float in_time, float in_elapsed_time)
{
	if (_pimpl->fsm_mgr != nullptr)
	{
		_pimpl->fsm_mgr->update(in_time, in_elapsed_time);
	}
}

// Bridge ���
FSM_ActorBridge* FSM_Enemy::bridge()
{
	return &_pimpl->bridge;
}

// FSM �� �޽��� ������
bool FSM_Enemy::sendMsg(char const* in_msg, void* in_data)
{
	return (_pimpl->fsm_mgr != nullptr) ?
		_pimpl->fsm_mgr->sendMsg(in_msg, in_data) : false;
}

// FSM ����
bool FSM_Enemy::change(void* in_state, bool in_force)
{
	if (_pimpl->fsm_mgr != nullptr)
	{
		if (in_force == false)
		{
			return _pimpl->fsm_mgr->change((FSM_BaseState<FSM_Enemy>*)in_state);
		}
		else
		{
			_pimpl->fsm_mgr->changeForce((FSM_BaseState<FSM_Enemy>*)in_state);
			return true;
		}
	}
	return false;
}

// FSM ���¾�� (-1:prev, 0:current, 1:next)
void* FSM_Enemy::getState(int in_type)
{
	if (_pimpl->fsm_mgr != nullptr)
	{
		switch (in_type)
		{
		case -1: return _pimpl->fsm_mgr->getPrevState();
		case 0: return _pimpl->fsm_mgr->getCurrState();
		case 1: return _pimpl->fsm_mgr->getNextState();
		}
	}
	return nullptr;
}

// FSM ���� ���·� ������
bool FSM_Enemy::backToPrevState()
{
	return (_pimpl->fsm_mgr != nullptr) ?
		_pimpl->fsm_mgr->backToPrevState() : false;
}

void FSM_Enemy::updateNextAngle()
{
	float curr_angle = UTIL_FUNCS::AngleNormalize(getAngle());

	float const res = UTIL_FUNCS::getTimeDir(curr_angle, getNextAngle());
	if( res ==  0.0f )
		return;

	float const adj =
		getAdjustAngleSpeed() * Vision::GetTimer()->GetTimeDifference();

	if ( res > 0.0f)
	{
		if (curr_angle < getNextAngle()) { curr_angle += 360.0f; }
		setAngle(__max(curr_angle - adj, getNextAngle()));
	}
	else
	{
		if (curr_angle > getNextAngle()) { curr_angle -= 360.0f; }
		setAngle(__min(curr_angle + adj, getNextAngle()));
	}
}

// �̵� ó��
void FSM_Enemy::processMove()
{
	_pimpl->bridge.fn_processMove();
}

// ���� ���� �ֱ�
void FSM_Enemy::pushAttack(unsigned int in_skill_id, unsigned char in_skill_lv,
		unsigned int in_skill_motion)
{
	if (in_skill_motion == 0) return;
	
	std::shared_ptr<ENEMY::ATTACK_DATA> data(new ENEMY::ATTACK_DATA);
	data->skill_id = in_skill_id;
	data->skill_lv = in_skill_lv;
	data->skill_motion = in_skill_motion;
	_pimpl->atk_infos.push_back(data);
	
}

// ���� ���� ����
void FSM_Enemy::popAttack()
{
	if (_pimpl->atk_infos.size() > 0)
	{
		_pimpl->atk_infos.pop_front();
	}
}

// ��� ���� ����
void FSM_Enemy::popAllAttack()
{
	_pimpl->atk_infos.clear();
}

// ���� ó�� ���Ҵ��� �˻�
bool FSM_Enemy::isAttackRemain(unsigned int in_skill_motion)
{
	return (_pimpl->atk_infos.size() > 0) &&
		(_pimpl->atk_infos.front()->skill_motion == in_skill_motion );
}

// ���� ��ų motion ���
unsigned int FSM_Enemy::getSkill_Motion(unsigned char in_index)
{
	VASSERT(in_index < 2);

	if (_pimpl->atk_infos.size() < static_cast<size_t>((in_index == 0) ? 1 : 2))
	{
		return 0;
	}

	auto iter = _pimpl->atk_infos.begin();
	return (in_index == 0) ? (*iter)->skill_motion : (*(++iter))->skill_motion;
}
// ���� ��ų id ���
unsigned int FSM_Enemy::getSkill_ID(unsigned char in_index)
{
	VASSERT(in_index < 2);

	if (_pimpl->atk_infos.size() < static_cast<size_t>((in_index == 0) ? 1 : 2))
	{
		return 0;
	}

	auto iter = _pimpl->atk_infos.begin();
	return (in_index == 0) ? (*iter)->skill_id : (*(++iter))->skill_id;
}
// ���� ��ų lv ���
unsigned int FSM_Enemy::getSkill_LV(unsigned char in_index)
{
	VASSERT(in_index < 2);

	if (_pimpl->atk_infos.size() < static_cast<size_t>((in_index == 0) ? 1 : 2))
	{
		return 0;
	}

	auto iter = _pimpl->atk_infos.begin();
	return (in_index == 0) ? (*iter)->skill_lv : (*(++iter))->skill_lv;
}

// �� �ǰݽ� ���� ó��
void FSM_Enemy::shake()
{
	_pimpl->bridge.fn_shake();
}

// �� ��� Ȯ��
int FSM_Enemy::getEnemyGrade()
{
	return _pimpl->bridge.fn_getEnemyGrade();
}

// �������� ������ �������� ��Ī
void FSM_Enemy::syncMatchNetOrientation()
{
	_pimpl->bridge.fn_syncNetOrientation();
}

//���ٵ� ���� ����
void FSM_Enemy::setStandState(STAND_STATE in_value)
{
	_pimpl->stand_state = in_value;
}

//���ٵ� ���� ���
FSM_Enemy::STAND_STATE FSM_Enemy::getStandState()
{
	return _pimpl->stand_state;
}

void FSM_Enemy::setJumpState(JUMP_STATE in_value)
{
	_pimpl->jump_info.jump_state = in_value;
	if(JS_START == _pimpl->jump_info.jump_state)
	{
		_pimpl->jump_info.jump_dir = getDirection();
	}
}

FSM_Enemy::JUMP_STATE FSM_Enemy::getJumpState()
{
	return _pimpl->jump_info.jump_state;
}

void FSM_Enemy::setJumpPos(hkvVec3 const& in_pos)
{
	_pimpl->jump_info.jump_landingPos = in_pos;
}

const hkvVec3& FSM_Enemy::getJumpPos()
{
	return _pimpl->jump_info.jump_landingPos;
}

void FSM_Enemy::setJumpSpeed(float fSpeed)
{
	_pimpl->jump_info.jump_speed = fSpeed;
}

float FSM_Enemy::getJumpSpeed()
{
	return _pimpl->jump_info.jump_speed;
}

void FSM_Enemy::SetJumpHeight(float fHeight)
{
	_pimpl->jump_info.jump_org_height = _pimpl->jump_info.jump_height;
	_pimpl->jump_info.jump_height = fHeight;
}

float FSM_Enemy::getJumpHeight()
{
	return _pimpl->jump_info.jump_height;
}

// �Է� ��ġ�� ���ϰ� ���� ȸ��
void FSM_Enemy::forceLookAt(hkvVec3 const& in_pos, bool in_back)
{
	hkvVec3 enemy_dir = getDirection();
	enemy_dir.z = 0.0f;
	hkvVec3 move_dir = in_back ?
		-(in_pos - getPosition()) : (in_pos - getPosition());
	move_dir.z = 0.0f;

	float const between_angle = enemy_dir.getAngleBetween(move_dir);
	float const cross = enemy_dir.cross(move_dir).z;
	float curr_angle = UTIL_FUNCS::AngleNormalize(getAngle());

	float angle = UTIL_FUNCS::AngleNormalize(
		(cross < 0.0f) ?
		curr_angle - between_angle :
	curr_angle + between_angle
		);

	setAngle(angle);
}

// ���ݴ��id ���
bool FSM_Enemy::getAttackTargetid(unsigned int& out_id)
{
	if (_pimpl->atk_infos.size() < 1 )
	{
		return false;
	}

	out_id  = _pimpl->atk_infos.front()->target_id;
	return true;
}

unsigned int FSM_Enemy::getSpecialAdventID()
{
	return _pimpl->bridge.fn_getSpecialAdventID();
}

void FSM_Enemy::setSpecialAdventID(unsigned int uiIndex)
{
	_pimpl->_AdventAniID = uiIndex;
}

bool FSM_Enemy::isSpecialAdvent()
{
	return _pimpl->bridge.fn_isSpecialAdvent();
}

void FSM_Enemy::setSpecialAdventFlag(bool bFlag)
{
	_pimpl->_AdventFlag = bFlag;
}