#include "stdafx.h"
#include <hash_map>
#include <functional>
#include "FSM_BaseMsg.hpp"
#include "FSM_BaseState.hpp"
#include "FSM_Manager.hpp"
#include "FSM_Actor.h"
#include "FSM_Enemy.h"
#include "FSM_Enemy_Msg.h"
#include "FSM_Enemy_State.h"
#include "..\EventManager\EventPlayer.h"
#include "..\EventManager\GeneralAniID.h"

namespace
{
	// �Ϲ����� �ִϸ��̼� ���� ó��
	void Process_AniEnd(FSM_Enemy* in_enemy)
	{
		if (in_enemy->getState(1))
		{
			in_enemy->change(in_enemy->getState(1));
		}
		else
		{
			in_enemy->change(FSM_Enemy_Stand::state());
		}
	}
	// Ư�����°� �ɶ����� ��ٸ��� ���� �� �ִϸ��̼��� ������ ��Ʋ��� �ִ����
	void Process_PreReady_AniEnd(FSM_Enemy* in_enemy)
	{
		in_enemy->getEventPlayer()->replayAni();
	}
}

//------------------------------------------------------------------------------
// �� ���ֱ� ����
//------------------------------------------------------------------------------

void FSM_Enemy_Stand::enter(FSM_Enemy* in_enemy)
{
	if (in_enemy->getBattleMaintainTime() > 0.0f)
	{
		in_enemy->setStandState(FSM_Enemy::ST_CHANGE_BATTLE);
	}
	else
	{
		in_enemy->setStandState(FSM_Enemy::ST_CHANGE_IDLE);
	}
}

void FSM_Enemy_Stand::leave(FSM_Enemy* in_enemy)
{
}

void FSM_Enemy_Stand::update(FSM_Enemy* in_enemy,
	float in_time, float in_elapsed_time)
{
	float const gpos_len = in_enemy->getGroundPosLen();
	if (gpos_len > in_enemy->getMoveRangeMin())
	{
		in_enemy->change(static_cast<void*>(FSM_Enemy_MoveToAttack::state()));
	}
	else
	{
		switch( in_enemy->getStandState() )
		{
		case FSM_Enemy::ST_CHANGE_BATTLE:
			in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_BATTLE_IDLE);
			in_enemy->setStandState(FSM_Enemy::ST_BATTLE);
			break;
		case FSM_Enemy::ST_CHANGE_IDLE:
			in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_NORMAL_IDLE);
			in_enemy->setStandState(FSM_Enemy::ST_IDLE);
			break;
		case FSM_Enemy::ST_BATTLE:
			in_enemy->updateBattleMaintainTime(in_elapsed_time);
			if (in_enemy->getBattleMaintainTime() <= 0.0f)
			{
				in_enemy->setStandState(FSM_Enemy::ST_CHANGE_IDLE);
			}
			break;
		case FSM_Enemy::ST_IDLE:
			if( in_enemy->getBattleMaintainTime() > 0.0f )
			{
				 in_enemy->setStandState(FSM_Enemy::ST_CHANGE_BATTLE);
			}
			break;
		}
	}
}

//------------------------------------------------------------------------------
// �� ��ǥ�̵� �⺻ ����
//------------------------------------------------------------------------------
void FSM_Enemy_MoveBase::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(getAni(), in_enemy->getMoveSpeed());
	in_enemy->updateAngleToGround();
}
void FSM_Enemy_MoveBase::leave(FSM_Enemy* in_enemy)
{
	if( in_enemy->getState(0) == FSM_Enemy_MoveToAttack::state() &&
		in_enemy->getState(1) == FSM_Enemy_MoveToGround::state() )
	{
		_asm nop;
	}

}

void FSM_Enemy_MoveBase::update(FSM_Enemy* in_enemy,
	float in_time, float in_elapsed_time)
{
	in_enemy->updateBattleMaintainTime(in_elapsed_time);

	if (in_enemy->updateAngleToGround() == false)
	{
		in_enemy->change(FSM_Enemy_Stand::state());
	}
	else
	{
		in_enemy->processMove();
	}
}

//------------------------------------------------------------------------------
// �� ������ǥ�� �̵� ����
//------------------------------------------------------------------------------
unsigned int FSM_Enemy_MoveToGround::getAni()
{
	return PUPPET_GENERAL_ANI_WALK;
}

//------------------------------------------------------------------------------
// �� ������ǥ�� �̵� ����
//------------------------------------------------------------------------------
unsigned int FSM_Enemy_MoveToAttack::getAni()
{
	return PUPPET_GENERAL_ANI_RUSH;
}

//------------------------------------------------------------------------------
// �� �׼� ��� ����
//------------------------------------------------------------------------------
void FSM_Enemy_PlayAction::enter(FSM_Enemy* in_enemy)
{
	in_enemy->setBattleMaintainTime(0.0f);
	in_enemy->setNextAngle(in_enemy->getNetAngle());
	in_enemy->getEventPlayer()->playAni(in_enemy->getActionID(), 1.0f, true);
	in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(&Process_AniEnd, in_enemy));
}
void FSM_Enemy_PlayAction::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_PlayAction::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->updateBattleMaintainTime(in_elapsed_time);
	in_enemy->slideToGroundPos();
	in_enemy->updateNextAngle();
}


//------------------------------------------------------------------------------
// �� �׼� �ð���� ����
//------------------------------------------------------------------------------
void FSM_Enemy_PlayTimeAction::enter(FSM_Enemy* in_enemy)
{
	in_enemy->setNextAngle(in_enemy->getNetAngle());
	in_enemy->getEventPlayer()->playAni(in_enemy->getActionID(), 1.0f);
}
void FSM_Enemy_PlayTimeAction::leave(FSM_Enemy* in_enemy)
{
}

void FSM_Enemy_PlayTimeAction::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->setTempFloat(in_enemy->getTempFloat() - in_elapsed_time);
	if( in_enemy->getTempFloat() <= 0.0f )
	{
		Process_AniEnd(in_enemy);
	}

	in_enemy->updateBattleMaintainTime(in_elapsed_time);
	in_enemy->slideToGroundPos();
	in_enemy->updateNextAngle();
}


//------------------------------------------------------------------------------
// �� ���ݾ׼� ��� ����
//------------------------------------------------------------------------------
namespace
{
	// ���� �ִϸ��̼� ���� ó��
	void Process_AttackAniEnd(FSM_Enemy* in_enemy)
	{
		float fTime = Vision::GetTimer()->GetTime();

		

		if (in_enemy->getState(1))
		{
			in_enemy->change(in_enemy->getState(1));
		}
		else if (in_enemy->getSkill_Motion(1) != 0)
		{
			if (in_enemy->getSkill_Motion(0) == in_enemy->getSkill_Motion(1))
			{
				in_enemy->getEventPlayer()->
					replayAni(in_enemy->getAttackSpeed());
			}
			else
			{
				in_enemy->getEventPlayer()->playAni(in_enemy->getSkill_Motion(1),
					in_enemy->getAttackSpeed(), true);
			}
			in_enemy->popAttack();
		}
		else
		{
			in_enemy->change(FSM_Enemy_Stand::state());
		}
	}
}

FSM_Enemy_PlayAttack::READY_RESULT
	FSM_Enemy_PlayAttack::leaveReady(FSM_Enemy* in_enemy)
{
	return FSM_Enemy_PlayAttack::READY_SUCCESS;
}

void FSM_Enemy_PlayAttack::enter(FSM_Enemy* in_enemy)
{
	float fTime = Vision::GetTimer()->GetTime();

	in_enemy->setNextAngle(in_enemy->getNetAngle());
	if( in_enemy->getEventPlayer()->playAni(in_enemy->getSkill_Motion(0), 
		in_enemy->getAttackSpeed(), true) == false )
	{
		in_enemy->change(FSM_Enemy_Stand::state());
	}

	in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(&Process_AttackAniEnd, in_enemy));

	in_enemy->setTimingEventFunc("SKILL_FIRE",
		[in_enemy](VisBaseEntity_cl* in_entity, char const* in_dummy,
			hkvVec3 const& in_addpos, char const* in_ext_info) -> void
		{
			in_enemy->onCombatMode();
			in_enemy->fireAttack(in_enemy->getSkill_Motion(0),
				in_enemy->getSkill_LV(0));
		}
	);
}

void FSM_Enemy_PlayAttack::leave(FSM_Enemy* in_enemy)
{
	float fTime = Vision::GetTimer()->GetTime();
	in_enemy->popAttack();
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
	in_enemy->setTimingEventFunc("SKILL_FIRE", nullptr);
}
void FSM_Enemy_PlayAttack::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->setNextAngle(in_enemy->getNetAngle());
	in_enemy->slideToGroundPos();
	in_enemy->updateNextAngle();
}

void FSM_Enemy_PlayAttackChanger::enter(FSM_Enemy* in_enemy)
{
	in_enemy->change(FSM_Enemy_PlayAttack::state());
}
//------------------------------------------------------------------------------
// �� �ǰ� ��� ����
//------------------------------------------------------------------------------
void FSM_Enemy_PlayHitting::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_HIT, 1.0f, true);
	in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(&Process_AniEnd, in_enemy));
}
void FSM_Enemy_PlayHitting::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}
void FSM_Enemy_PlayHitting::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->slideToGroundPos();
}

//------------------------------------------------------------------------------
// �� ��� ��� ����
//------------------------------------------------------------------------------
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_DieReady::enterReady(FSM_Enemy* in_enemy)
{
	return READY_FORCE;
}
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_DieReady::leaveReady(FSM_Enemy* in_enemy)
{
	return READY_FAIL;
}
void FSM_Enemy_DieReady::enter(FSM_Enemy* in_enemy)
{
	in_enemy->setTempFloat(0.0f);
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_BATTLE_IDLE, 1.0f, true);
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}
void FSM_Enemy_DieReady::leave(FSM_Enemy* in_enemy)
{
}
void FSM_Enemy_DieReady::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->setTempFloat(in_enemy->getTempFloat() + in_elapsed_time);
	if (in_enemy->getTempFloat() > 0.6f)
	{
		in_enemy->change(FSM_Enemy_Die::state());
	}
}

//------------------------------------------------------------------------------
// �� ��� ����
//------------------------------------------------------------------------------
namespace
{
	void FinishedDieAni(FSM_Enemy* in_enemy)
	{
		in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
		in_enemy->processDieAniEnd();
	}
}
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_Die::enterReady(FSM_Enemy* in_enemy)
{
	return READY_FORCE;
}
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_Die::leaveReady(FSM_Enemy* in_enemy)
{
	return READY_FAIL;
}
void FSM_Enemy_Die::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_DEATH, 1.0f, true);
	in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(FinishedDieAni, in_enemy));

	in_enemy->processDieAniStart();
}
void FSM_Enemy_Die::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
}


//------------------------------------------------------------------------------
// �÷��̾� �һ� ����
//------------------------------------------------------------------------------
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_Rivive::enterReady(FSM_Enemy* in_enemy)
{
	return FSM_BaseState<FSM_Enemy>::READY_FORCE;
}
void FSM_Enemy_Rivive::enter(FSM_Enemy* in_enemy)
{
	in_enemy->processRevive();
}
void FSM_Enemy_Rivive::update(FSM_Enemy* in_enemy,
	float in_time, float in_elapsed_time)
{
	in_enemy->change(FSM_Enemy_Stand::state());
}

//------------------------------------------------------------------------------
// �� ���� ����
//------------------------------------------------------------------------------
FSM_Enemy_Sleep::READY_RESULT FSM_Enemy_Sleep::enterReady(FSM_Enemy* in_enemy)
{
	return FSM_Enemy_Sleep::READY_FORCE;
}
void FSM_Enemy_Sleep::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_STUN);
}

//------------------------------------------------------------------------------
// �� ������ȯ ����
//------------------------------------------------------------------------------
FSM_Enemy_Draging::READY_RESULT FSM_Enemy_Draging::enterReady(FSM_Enemy* in_enemy)
{
	return FSM_Enemy_Draging::READY_FORCE;
}

void FSM_Enemy_Draging::update(
		FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	if(in_enemy->getGroundPosLen() < in_enemy->getMoveRangeMin() )
	{
		if (in_enemy->getState(1))
		{
			in_enemy->change(in_enemy->getState(1));
		}
		else
		{
			in_enemy->change(FSM_Enemy_Stand::state());
		}
	}
	else
	{
		in_enemy->slideToGroundPos(12.0f);
	}
}


namespace
{
	static const float KNOCKBACK_SPEED	= 11.0f;
	static const float KNOCKBACK_G		= 9.8f*6.0f;

	void FinishedAni_knockbackDown(FSM_Enemy* in_enemy)
	{
		in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
		in_enemy->syncMatchNetOrientation();
		in_enemy->setKnockbackState(3);

		void* properstate = FSM_Enemy_Stand::state();
		if( in_enemy->isDead() ){
			properstate = FSM_Enemy_Die::state();
		}
		else if( in_enemy->isState(FSM_Actor::STUN) )	{
			properstate = FSM_Enemy_Stun::state();
		}
		else if( in_enemy->isState(FSM_Actor::SLEEP) )	{
			properstate = FSM_Enemy_Sleep::state();
		}
		else if( in_enemy->getState(1) )	{
			properstate = in_enemy->getState(1);
		}

		in_enemy->change(properstate);
	}

	void ChangeMotionKnockbackDown(FSM_Enemy* in_enemy)
	{
		in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_KNOCKBACK_DOWN,
			1.0f, true);

		in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(FinishedAni_knockbackDown, in_enemy));
	}

	void FinishedAni_knockbackDie(FSM_Enemy* in_enemy)
	{
		in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
		in_enemy->processDieAniEnd();
	}

	void ChangeMotionKnockbackDie(FSM_Enemy* in_enemy)
	{
		in_enemy->processDieAniStart();
		in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_KNOCKBACK_DOWN,
			1.0f, true);

		in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(FinishedAni_knockbackDie, in_enemy));
		
	}

	auto CalcHeight = [](float in_diff_time, FSM_Enemy* in_enemy) -> float
	{
		// s = �̵��Ÿ�
		// u = �ʱ�ӵ�
		// a = ���ӵ�
		// t = �ð�
		// v = �����ӵ�
		const float G = -KNOCKBACK_G;
		float  gravMovementInFrame = 0.0f;

		//s = u*t + 0.5*a*t*t
		
		float tempVec = in_enemy->getTempFloat();
		tempVec *= in_diff_time;
		gravMovementInFrame += tempVec;

		tempVec = G/** mass*/;
		tempVec *= (float) (0.5 * in_diff_time * in_diff_time);
		gravMovementInFrame += tempVec;

		//v = u + a*t
		tempVec = G;
		tempVec *= in_diff_time;
		in_enemy->setTempFloat(in_enemy->getTempFloat() + tempVec);
		return gravMovementInFrame;
	};

	auto CalcNextPos = [](float in_diff_time, FSM_Enemy* in_enemy,
		float& out_Distance_ratio) -> hkvVec3
	{
		hkvVec3 const curr_pos = in_enemy->getPosition();
		hkvVec3 const to_pos =	in_enemy->getKnockbackPos();
		
		if ((curr_pos.x == to_pos.x && curr_pos.y == to_pos.y) ||
			in_enemy->getKnockbackSpeed() == 0.0f )
		{
			out_Distance_ratio = 1.0f;
			return curr_pos;
		}

		auto getDir_2d = [](hkvVec3 const& in_dir) -> hkvVec3
		{
			hkvVec3 dir(in_dir.x, in_dir.y, 0.0f);
			dir.normalizeIfNotZero();
			return dir;
		};
			

		hkvVec3 const start_dir = getDir_2d(to_pos - curr_pos);
		hkvVec3 next_pos = curr_pos + start_dir * in_diff_time * in_enemy->getKnockbackSpeed();
		hkvVec3 const next_dir = getDir_2d(to_pos - next_pos);

		if (start_dir.dot(next_dir) < 0.0f)
		{
			next_pos.x = to_pos.x;
			next_pos.y = to_pos.y;
			next_pos.z = curr_pos.z;
			out_Distance_ratio = 1.0f;
			return next_pos;
		}

		float curDist = next_pos.getAsVec2().getDistanceTo(to_pos.getAsVec2());
		out_Distance_ratio = (in_enemy->getKB_length() - curDist) / in_enemy->getKB_length();
		out_Distance_ratio = __min(1.f, __max(0.0f,out_Distance_ratio)); 
		return next_pos;
	};

}
//------------------------------------------------------------------------------
// �� �˹� ����
//------------------------------------------------------------------------------
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_knockback::leaveReady(FSM_Enemy* in_enemy)
{
	return (in_enemy->getKnockbackState() == 3) ?
		FSM_BaseState<FSM_Enemy>::READY_SUCCESS :
		FSM_BaseState<FSM_Enemy>::READY_FAIL;
}

void FSM_Enemy_knockback::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_KNOCKBACK,1.0f,true);

	in_enemy->setKnockbackState(0);
	float UpForce = 0.0f;
	if( in_enemy->getKB_length() > 6.0f )
	{
		UpForce = in_enemy->getKB_length() / KNOCKBACK_SPEED;
		in_enemy->setKnockbackSpeed(KNOCKBACK_SPEED);
	}
	else
	{
		UpForce = 0.6f;
		in_enemy->setKnockbackSpeed(in_enemy->getKB_length()/UpForce );
	}

	in_enemy->setTempFloat(UpForce * KNOCKBACK_G * 0.5f);
	if( in_enemy->getVolume() > 0.5f )
	{
		float reduce = __max(1.0f-((in_enemy->getVolume() - 0.5f)*0.4f), 0.5f);
		in_enemy->setTempFloat(in_enemy->getTempFloat()*reduce);
	}
}

void FSM_Enemy_knockback::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_knockback::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	float distRatio = 0.0f;
	hkvVec3 knock_pos	= CalcNextPos(in_elapsed_time, in_enemy, distRatio);
	float movedelta		= 0.0f;
	
	switch (in_enemy->getKnockbackState())
	{
	case 0:
		{
			movedelta = CalcHeight(in_elapsed_time, in_enemy);
			if( movedelta < 0 )	{
				in_enemy->setKnockbackState(1);
				Vision::Error.SystemMessage("%d : DropTime DistanceRatio[%.2f]", PtrToUint(in_enemy), distRatio);
			}
		}
		break;
	case 1:
	case 2:
		{
			float fGoundH;
			in_enemy->isLandedGround(&fGoundH);
			movedelta = CalcHeight(in_elapsed_time, in_enemy);
			float nextHeight = movedelta + in_enemy->getPosition().z;
			if( fGoundH >= nextHeight )
			{
				movedelta += fGoundH - nextHeight;
				if( in_enemy->getKnockbackState() == 1 )
				{
					ChangeMotionKnockbackDown(in_enemy);
					in_enemy->setKnockbackState(2);
				}
			}
		}
		break;
	}
	
	knock_pos.z += movedelta;
	in_enemy->setNopickPos(knock_pos);
}

//------------------------------------------------------------------------------
// �� �˹����� ����
//------------------------------------------------------------------------------
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_knockbackDie::enterReady(FSM_Enemy* in_enemy)
{
	return READY_FORCE;
}
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_knockbackDie::leaveReady(FSM_Enemy* in_enemy)
{
	return READY_FAIL;
}

void FSM_Enemy_knockbackDie::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_KNOCKBACK,1.0f,true);

	in_enemy->setKnockbackState(0);
	float UpForce = 0.0f;
	if( in_enemy->getKB_length() > 6.0f )
	{
		UpForce = in_enemy->getKB_length() / KNOCKBACK_SPEED;
		in_enemy->setKnockbackSpeed(KNOCKBACK_SPEED);
	}
	else
	{
		UpForce = 0.6f;
		in_enemy->setKnockbackSpeed(in_enemy->getKB_length()/UpForce );
	}

	in_enemy->setTempFloat(UpForce * KNOCKBACK_G * 0.5f);
	if( in_enemy->getVolume() > 0.5f )
	{
		float reduce = __max(1.0f-((in_enemy->getVolume() - 0.5f)*0.4f), 0.5f);
		in_enemy->setTempFloat(in_enemy->getTempFloat()*reduce);
	}
}

void FSM_Enemy_knockbackDie::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_knockbackDie::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	float distRatio = 0.0f;
	hkvVec3 knock_pos	= CalcNextPos(in_elapsed_time, in_enemy, distRatio);
	float movedelta			= 0.0f;
	
	switch (in_enemy->getKnockbackState())
	{
	case 0:
		{
			movedelta = CalcHeight(in_elapsed_time, in_enemy);
			if( movedelta < 0 )	{
				in_enemy->setKnockbackState(1);
				//Vision::Error.SystemMessage("%d : DropTime DistanceRatio[%.2f]", PtrToUint(in_enemy), distRatio);
			}
		}
		break;
	case 1:
		{
			float fGoundH;
			in_enemy->isLandedGround(&fGoundH);
			movedelta = CalcHeight(in_elapsed_time, in_enemy);
			float nextHeight = movedelta + in_enemy->getPosition().z;
			if( fGoundH >= nextHeight )
			{
				movedelta += fGoundH - nextHeight;
				ChangeMotionKnockbackDie(in_enemy);
				in_enemy->setKnockbackState(2);
			}
		}
		break;
	case 2:
		return;
	}
	knock_pos.z += movedelta;
	in_enemy->setNopickPos(knock_pos);
}

//------------------------------------------------------------------------------
// �� ���� ����
//------------------------------------------------------------------------------
FSM_Enemy_Stun::READY_RESULT FSM_Enemy_Stun::enterReady(FSM_Enemy* in_enemy)
{
	return FSM_Enemy_Stun::READY_FORCE;
}

void FSM_Enemy_Stun::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_STUN);
}

void FSM_Enemy_Stun::update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
float distRatio = 0.0f;
	hkvVec3 knock_pos	= CalcNextPos(in_elapsed_time, in_enemy, distRatio);
	in_enemy->isLandedGround(&knock_pos.z);
	in_enemy->setNopickPos(knock_pos);
}

//------------------------------------------------------------------------------
// �� �и� ����
//------------------------------------------------------------------------------
FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_Slideback::leaveReady(FSM_Enemy* in_enemy)
{
	return (in_enemy->getKnockbackState() == 3) ?
		FSM_BaseState<FSM_Enemy>::READY_SUCCESS :
		FSM_BaseState<FSM_Enemy>::READY_FAIL;
}

void FSM_Enemy_Slideback::enter(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_HIT,1.0f,true);
	in_enemy->setKnockbackState(0);
	in_enemy->setTempFloat(10.0f);
	in_enemy->setKnockbackSpeed(KNOCKBACK_SPEED);
}

void FSM_Enemy_Slideback::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_Slideback::update(
	FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	float distRatio = 0.0f;
	hkvVec3 knock_pos	= CalcNextPos(in_elapsed_time, in_enemy, distRatio);
	in_enemy->isLandedGround(&knock_pos.z);
	in_enemy->setNopickPos(knock_pos);

	if( distRatio == 1.0f && 
		in_enemy->getKnockbackState() != 3 )
	{
		in_enemy->getEventPlayer()->setAniendFireNotifier(
		std::bind(FinishedAni_knockbackDown, in_enemy));
	}
}

//------------------------------------------------------------------------------
// �� ���� ���� ����
//------------------------------------------------------------------------------

namespace
{
	auto CalcNextJumpPos = [](float in_diff_time, FSM_Enemy* in_enemy) -> hkvVec3
	{
		hkvVec3 const curr_pos = in_enemy->getPosition();
		hkvVec3 const to_pos =	in_enemy->getJumpPos();
		if (curr_pos.x == to_pos.x && curr_pos.y == to_pos.y) {
			return curr_pos;
		}

		auto getDir_2d = [](hkvVec3 const& in_dir) -> hkvVec3
		{
			hkvVec3 dir(in_dir.x, in_dir.y, 0.0f);
			dir.normalizeIfNotZero();
			return dir;
		};

		hkvVec3 const start_dir = getDir_2d(to_pos - curr_pos);
		hkvVec3 next_pos = curr_pos + start_dir * in_diff_time * in_enemy->getJumpSpeed();
		hkvVec3 const next_dir = getDir_2d(to_pos - next_pos);
		in_enemy->adjustAngleToPos(to_pos, start_dir, false);

		if (start_dir.dot(next_dir) < 0.0f) {
			next_pos.x = to_pos.x;
			next_pos.y = to_pos.y;
			next_pos.z = curr_pos.z;
		}

		return next_pos;
	};

	auto CalcJumpHeight = [](float in_diff_time, FSM_Enemy* in_enemy) -> float
	{
		// s = �̵��Ÿ�
		// u = �ʱ�ӵ�
		// a = ���ӵ�
		// t = �ð�
		// v = �����ӵ�
		const float G = -19.6f/*9.8f*2.0f*/;
		float  gravMovementInFrame = 0.0f;

		//s = u*t + 0.5*a*t*t
		float tempVec = in_enemy->getJumpHeight();
		tempVec *= in_diff_time;
		gravMovementInFrame += tempVec;

		tempVec = G;
		tempVec *= (float) (0.5 * in_diff_time * in_diff_time);
		gravMovementInFrame += tempVec;

		//v = u + a*t
		tempVec = G;
		tempVec *= in_diff_time;
		in_enemy->SetJumpHeight(in_enemy->getJumpHeight() + tempVec);
		return gravMovementInFrame;
	};
}

FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_Jump::enterReady(FSM_Enemy* in_enemy)
{
	return READY_FORCE;
}

FSM_BaseState<FSM_Enemy>::READY_RESULT
	FSM_Enemy_Jump::leaveReady(FSM_Enemy* in_enemy)
{
	return (FSM_Enemy::JS_LANDING == in_enemy->getJumpState()) ?
		FSM_BaseState<FSM_Enemy>::leaveReady(in_enemy) :
		FSM_BaseState<FSM_Enemy>::READY_WAIT;
}

void FSM_Enemy_Jump::enter(FSM_Enemy* in_enemy)
{
	jump_start_ani(in_enemy);
	in_enemy->getEventPlayer()->setAniendFireNotifier(std::bind(&FSM_Enemy_Jump::jump_start_aniEnd, this, in_enemy));
	in_enemy->setJumpState(FSM_Enemy::JS_START);
}

void FSM_Enemy_Jump::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_Jump::update(FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->updateBattleMaintainTime(in_elapsed_time);

	hkvVec3 move_pos;
	float jump_delta = 0.0f;
	if(FSM_Enemy::JS_LANDING > in_enemy->getJumpState())
	{
		move_pos = CalcNextJumpPos(in_elapsed_time, in_enemy);
		jump_delta = CalcJumpHeight(in_elapsed_time, in_enemy);
	}

	switch (in_enemy->getJumpState())
	{
	case FSM_Enemy::JS_START:
		{
			if( jump_delta < 0 )
			{
				in_enemy->setJumpState(FSM_Enemy::JS_TOP_DOWN);
			}
		}
		break;
	case FSM_Enemy::JS_TOP_DOWN:
		{
			float fGroundHeight = 0.f;
			in_enemy->isLandedGround(&fGroundHeight);
			float nextHeight = jump_delta + in_enemy->getPosition().z;
			if(fGroundHeight >= nextHeight)
			{
				in_enemy->setTempFloat(0.0f);
				jump_Land(in_enemy);
			}
		}
		break;
	}
	move_pos.z += jump_delta;

	in_enemy->setNopickPos(move_pos);
}

void FSM_Enemy_Jump::jump_Land(FSM_Enemy* in_enemy)
{
	in_enemy->setJumpState(FSM_Enemy::JS_LANDING);
}

void FSM_Enemy_Jump::jump_start_aniEnd(FSM_Enemy* in_enemy)
{
	falling_signal(in_enemy);
}

//////////////////////////////////////////////////////////////////////////

void FSM_Enemy_JumpAttack::enter(FSM_Enemy* in_enemy)
{
	__super::enter(in_enemy);
	calcJumpSpeed(in_enemy);
	in_enemy->forceLookAt(in_enemy->getMoveToPos(), false);
}

void FSM_Enemy_JumpAttack::jump_start_ani(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_HIT, in_enemy->getMoveSpeed(), true);
}

void FSM_Enemy_JumpAttack::jump_Land(FSM_Enemy* in_enemy)
{
	__super::jump_Land(in_enemy);
	in_enemy->change(FSM_Enemy_LandingAttack::state());
}

void FSM_Enemy_JumpAttack::falling_signal(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_KNOCKBACK, in_enemy->getMoveSpeed());
}

void FSM_Enemy_JumpAttack::calcJumpSpeed(FSM_Enemy* in_enemy)
{
	hkvVec3 const curr_pos = in_enemy->getPosition();
	hkvVec3 const to_pos =	in_enemy->getJumpPos();

	float fPosX = abs(to_pos.x - curr_pos.x);
	float fPosY = abs(to_pos.y - curr_pos.y);
	in_enemy->setJumpSpeed((fPosX + fPosY) * 0.7f);
}

//////////////////////////////////////////////////////////////////////////

FSM_BaseState<FSM_Enemy>::READY_RESULT FSM_Enemy_LandingAttack::enterReady(FSM_Enemy* in_enemy)
{
	return (FSM_Enemy::JS_LANDING == in_enemy->getJumpState()) ?
		FSM_BaseState<FSM_Enemy>::enterReady(in_enemy) :
	FSM_BaseState<FSM_Enemy>::READY_FAIL;
}

FSM_BaseState<FSM_Enemy>::READY_RESULT FSM_Enemy_LandingAttack::leaveReady(FSM_Enemy* in_enemy)
{
	return (FSM_Enemy::JS_LANDED == in_enemy->getJumpState()) ?
		FSM_BaseState<FSM_Enemy>::leaveReady(in_enemy) :
	FSM_BaseState<FSM_Enemy>::READY_WAIT;
}

void FSM_Enemy_LandingAttack::enter(FSM_Enemy* in_enemy)
{
	Land_ani(in_enemy);
	in_enemy->getEventPlayer()->setAniendFireNotifier(std::bind(&FSM_Enemy_LandingAttack::Land_aniEnd, this, in_enemy));
}

void FSM_Enemy_LandingAttack::leave(FSM_Enemy* in_enemy)
{
	in_enemy->setJumpState(FSM_Enemy::JS_NONE);
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_LandingAttack::update(FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->updateBattleMaintainTime(in_elapsed_time);
}

void FSM_Enemy_LandingAttack::Land_ani(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(PUPPET_GENERAL_ANI_KNOCKBACK_DOWN, true);
}

void FSM_Enemy_LandingAttack::Land_aniEnd(FSM_Enemy* in_enemy)
{
	in_enemy->setJumpState(FSM_Enemy::JS_LANDED);
	Land_Finished(in_enemy);
}

void FSM_Enemy_LandingAttack::Land_Finished(FSM_Enemy* in_enemy)
{
	in_enemy->change(FSM_Enemy_Stand::state());
}

//////////////////////////////////////////////////////////////////////////

FSM_BaseState<FSM_Enemy>::READY_RESULT FSM_Enemy_Ambush::enterReady(FSM_Enemy* in_enemy)
{
	return FSM_BaseState<FSM_Enemy>::enterReady(in_enemy);
}

FSM_BaseState<FSM_Enemy>::READY_RESULT FSM_Enemy_Ambush::leaveReady(FSM_Enemy* in_enemy)
{
	return FSM_BaseState<FSM_Enemy>::leaveReady(in_enemy);
}

void FSM_Enemy_Ambush::enter(FSM_Enemy* in_enemy)
{
	SneakAtK_ani(in_enemy);
	in_enemy->getEventPlayer()->setAniendFireNotifier(std::bind(&FSM_Enemy_Ambush::SneakAtk_aniEnd, this, in_enemy));
}

void FSM_Enemy_Ambush::leave(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->setAniendFireNotifier(nullptr);
}

void FSM_Enemy_Ambush::update(FSM_Enemy* in_enemy, float in_time, float in_elapsed_time)
{
	in_enemy->updateBattleMaintainTime(in_elapsed_time);
}

void FSM_Enemy_Ambush::SneakAtK_ani(FSM_Enemy* in_enemy)
{
	in_enemy->getEventPlayer()->playAni(getSpecialAdventID(in_enemy), true);
}

void FSM_Enemy_Ambush::SneakAtk_aniEnd(FSM_Enemy* in_enemy)
{
	in_enemy->change(FSM_Enemy_Stand::state());
}

unsigned int FSM_Enemy_Ambush::getSpecialAdventID(FSM_Enemy* in_enemy)
{
	return in_enemy->getSpecialAdventID();
}
