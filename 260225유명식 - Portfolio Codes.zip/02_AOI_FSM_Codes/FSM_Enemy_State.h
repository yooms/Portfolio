#ifndef __FSM_ENEMY_STATE_H__
#define __FSM_ENEMY_STATE_H__

//------------------------------------------------------------------------------
// �� ���ֱ� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Stand, FSM_Enemy, FSM_EnemyMsg_Stand)
public:
    virtual char const* getName() { return "EnemyStand"; }
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ��ǥ�̵� �⺻ ����
//------------------------------------------------------------------------------
class FSM_Enemy_MoveBase : public FSM_BaseState<FSM_Enemy>
{
public:
    virtual unsigned int getAni() = 0;
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ������ǥ�� �̵� ����
//------------------------------------------------------------------------------
CLASS_INHERIT_FSM_STATE(FSM_Enemy_MoveToGround, FSM_Enemy_MoveBase, FSM_EnemyMsg_Move)
public:
    virtual char const* getName() { return "EnemyMoveToGround"; }
    unsigned int getAni();
};

//------------------------------------------------------------------------------
// �� ���ݴ�� ��ǥ�� �̵� ����
//------------------------------------------------------------------------------
CLASS_INHERIT_FSM_STATE(FSM_Enemy_MoveToAttack, FSM_Enemy_MoveBase, FSM_EnemyMsg_Move)
public:
    virtual char const* getName() { return "EnemyMoveToAttack"; }
    unsigned int getAni();
};

//------------------------------------------------------------------------------
// �� �׼� ��� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_PlayAction, FSM_Enemy, FSM_EnemyMsg_Action)
public:
    virtual char const* getName() { return "EnemyPlayAction"; }
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� �׼� �ð���� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_PlayTimeAction, FSM_Enemy, FSM_EnemyMsg_Action)
public:
    virtual char const* getName() { return "EnemyPlayTimeAction"; }
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ���ݾ׼� ��� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_PlayAttack, FSM_Enemy, FSM_EnemyMsg_Attack)
public:
    virtual char const* getName() { return "EnemyPlayAttack"; }
    virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

CLASS_FSM_STATE(FSM_Enemy_PlayAttackChanger, FSM_Enemy, FSM_EnemyMsg_Attack)
public:
    virtual char const* getName() { return "FSM_Enemy_PlayAttackChanger"; }
    virtual void enter(FSM_Enemy* in_enemy);
	virtual void update(
		FSM_Enemy* in_enemy, float in_time, float in_elapsed_time){}
};

//------------------------------------------------------------------------------
// �� �ǰ� ��� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_PlayHitting, FSM_Enemy, FSM_EnemyMsg_Move)
public:
    virtual char const* getName() { return "EnemyPlayHitting"; }
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ��� ��� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_DieReady, FSM_Enemy, FSM_EnemyMsg_DieReady)
public:
    virtual char const* getName() { return "EnemyDieReady"; }
    virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
    virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ��� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Die, FSM_Enemy, FSM_EnemyMsg_Die)
public:
    virtual char const* getName() { return "EnemyDie"; }
    virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
    virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ��Ȱ ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Rivive, FSM_Enemy, FSM_BaseMsg<FSM_Enemy>)
public:
    virtual char const* getName() { return "EnemyRivive"; }
    virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ���� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Sleep, FSM_Enemy, FSM_EnemyMsg_Sleep)
public:
    virtual char const* getName() { return "EnemySleep"; }
    virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time) {}
};

//------------------------------------------------------------------------------
// �� ������ȯ ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Draging, FSM_Enemy, FSM_BaseMsg<FSM_Enemy>)
public:
    virtual char const* getName() { return "EnemyDraging"; }
    virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
	virtual void enter(FSM_Enemy* in_enemy)	{};
	virtual void leave(FSM_Enemy* in_enemy)	{};
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� �˹� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_knockback, FSM_Enemy, FSM_EnemyMsg_Base)
public:
    virtual char const* getName() { return "Enemyknockback"; }
    virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
	virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� �˹����� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_knockbackDie, FSM_Enemy, FSM_EnemyMsg_Die)
public:
    virtual char const* getName() { return "EnemyknockbackDie"; }
	virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
    virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
	virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ���� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Stun, FSM_Enemy, FSM_EnemyMsg_Stun)
public:
    virtual char const* getName() { return "EnemyStun"; }
    virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� �и� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Slideback, FSM_Enemy, FSM_EnemyMsg_BaseSlideback)
public:
    virtual char const* getName() { return "EnemySlideback"; }
    virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
    virtual void enter(FSM_Enemy* in_enemy);
	virtual void leave(FSM_Enemy* in_enemy);
    virtual void update(
        FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
};

//------------------------------------------------------------------------------
// �� ���� ���� (���� - ���� - ���� ����)
//------------------------------------------------------------------------------
class FSM_Enemy_Jump : public FSM_BaseState<FSM_Enemy>
{
public:
	virtual char const* getName() { return "EnemyJump"; }
	virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
	virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
	virtual void enter(FSM_Enemy* in_enemy);
	virtual void leave(FSM_Enemy* in_enemy);
	virtual void update(FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);

protected:
	virtual void jump_start_ani(FSM_Enemy* in_enemy) {};
	virtual void jump_start_aniEnd(FSM_Enemy* in_enemy);
	virtual void jump_Land(FSM_Enemy* in_enemy);
	virtual void falling_signal(FSM_Enemy* in_enemy) = 0;
};

//------------------------------------------------------------------------------
// �� ���� ���� ���� (���� - ���� - ���� ����)
//------------------------------------------------------------------------------
CLASS_INHERIT_FSM_STATE(FSM_Enemy_JumpAttack, FSM_Enemy_Jump, FSM_EnemyMsg_JumpAttack)
public:
	virtual char const* getName() { return "EnemyJumpAttack"; }
	virtual void enter(FSM_Enemy* in_enemy);

protected:
	virtual void jump_start_ani(FSM_Enemy* in_enemy);
	virtual void jump_Land(FSM_Enemy* in_enemy);
	virtual void falling_signal(FSM_Enemy* in_enemy);

	virtual void calcJumpSpeed(FSM_Enemy* in_enemy);
};

//------------------------------------------------------------------------------
// �� ���� ���� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_LandingAttack, FSM_Enemy, FSM_EnemyMsg_LandingAttack)
public:
	virtual char const* getName() { return "EnemyLandingAttack"; }
	virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
	virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
	virtual void enter(FSM_Enemy* in_enemy);
	virtual void leave(FSM_Enemy* in_enemy);
	virtual void update(FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
protected:
	virtual void Land_ani(FSM_Enemy* in_enemy);
	virtual void Land_aniEnd(FSM_Enemy* in_enemy);
	virtual void Land_Finished(FSM_Enemy* in_enemy);
};

//------------------------------------------------------------------------------
// �� �ź� ���� ����
//------------------------------------------------------------------------------
CLASS_FSM_STATE(FSM_Enemy_Ambush, FSM_Enemy, FSM_EnemyMsg_Ambush)
public:
	virtual char const* getName() { return "EnemyAubush"; }
	virtual READY_RESULT enterReady(FSM_Enemy* in_enemy);
	virtual READY_RESULT leaveReady(FSM_Enemy* in_enemy);
	virtual void enter(FSM_Enemy* in_enemy);
	virtual void leave(FSM_Enemy* in_enemy);
	virtual void update(FSM_Enemy* in_enemy, float in_time, float in_elapsed_time);
protected:
	virtual void SneakAtK_ani(FSM_Enemy* in_enemy);
	virtual void SneakAtk_aniEnd(FSM_Enemy* in_enemy);
	virtual unsigned int getSpecialAdventID(FSM_Enemy* in_enemy);
};

#endif // #ifndef __FSM_ENEMY_STATE_H__
