#include "stdafx.h"
#include <hash_map>
#include <functional>
#include "FSM_BaseMsg.hpp"
#include "FSM_BaseState.hpp"
#include "FSM_Actor.h"
#include "FSM_Enemy.h"
#include "FSM_Enemy_Msg.h"
#include "FSM_Enemy_State.h"
#include "FSM_Manager.hpp"
#include <tuple>

//------------------------------------------------------------------------------
// �� �⺻ �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Base::FSM_EnemyMsg_Base()
{
	_funcs.insert(std::make_pair("MoveSpeedChange",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setAniSpeed(in_enemy->getMoveSpeed());
			return true;
	}
	));

	_funcs.insert(std::make_pair("AttackSpeedChange",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setAniSpeed(in_enemy->getAttackSpeed());
			return true;
	}
	));

	_funcs.insert(std::make_pair("CastSpeedChange",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setAniSpeed(in_enemy->getCastingSpeed());
			return true;
	}
	));

	_funcs.insert(std::make_pair("Die",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			return in_enemy->change(FSM_Enemy_DieReady::state());
		}
	));

	_funcs.insert(std::make_pair("KnockbackDie",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockbackDie::state(), true);
		}
	));
}

//------------------------------------------------------------------------------
// �� �Ϲ����� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_General::FSM_EnemyMsg_General()
{
	_funcs.insert(std::make_pair("MoveToGround",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setMoveToPos(*reinterpret_cast<hkvVec3*>(in_data));
			return in_enemy->change(FSM_Enemy_MoveToGround::state());
		}
	));

	_funcs.insert(std::make_pair("MoveToAttack",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setMoveToPos(*reinterpret_cast<hkvVec3*>(in_data));
			return in_enemy->change(FSM_Enemy_MoveToAttack::state());
		}
	));

	_funcs.insert(std::make_pair("JumpAttack",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setMoveToPos(*reinterpret_cast<hkvVec3*>(in_data));
			return in_enemy->change(FSM_Enemy_JumpAttack::state());
	}
	));

	_funcs.insert(std::make_pair("PlayAction",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setActionID(reinterpret_cast<
				std::pair<unsigned int, hkvVec3>*>(in_data)->first);

			in_enemy->setMoveToPos(reinterpret_cast<
				std::pair<unsigned int, hkvVec3>*>(in_data)->second);
			return in_enemy->change(FSM_Enemy_PlayAction::state());
		}
	));

	_funcs.insert(std::make_pair("PlayTimeAction",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {

			in_enemy->setActionID(reinterpret_cast<
				std::pair<unsigned int, std::pair<float, hkvVec3>>*>(in_data)->first);

			in_enemy->setTempFloat(reinterpret_cast<
				std::pair<unsigned int, std::pair<float, hkvVec3>>*>(in_data)->second.first);

			in_enemy->setMoveToPos(reinterpret_cast<
				std::pair<unsigned int, std::pair<float, hkvVec3>>*>(in_data)->second.second);

			return in_enemy->change(FSM_Enemy_PlayTimeAction::state());
		}
	));

	_funcs.insert(std::make_pair("PlayAttack",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			std::tuple<unsigned int, unsigned char, unsigned int>* pData =
			reinterpret_cast<std::tuple<unsigned int, unsigned char, unsigned int>*>(in_data);
			in_enemy->pushAttack(
				std::get<0>(*pData), 
				std::get<1>(*pData),
				std::get<2>(*pData));
			return in_enemy->change(FSM_Enemy_PlayAttack::state());
		}
	));

	_funcs.insert(std::make_pair("StunOn",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			return in_enemy->change(FSM_Enemy_Stun::state());
		}
	));

	_funcs.insert(std::make_pair("SleepOn",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			return in_enemy->change(FSM_Enemy_Sleep::state());
		}
	));

	_funcs.insert(std::make_pair("Draging",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setMoveToPos(*reinterpret_cast<hkvVec3*>(in_data));
			return in_enemy->change(FSM_Enemy_Draging::state());
		}
	));

	_funcs.insert(std::make_pair("HoldOn",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setBattleMaintainTime(100.0f);
			return true;
		}
	));

	_funcs.insert(std::make_pair("HoldOff",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->onCombatMode();
			return true;
		}
	));
}

//------------------------------------------------------------------------------
// �� ���ֱ� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Stand::FSM_EnemyMsg_Stand()
{
	_funcs.insert(std::make_pair("PlayHitting",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			return in_enemy->change(FSM_Enemy_PlayHitting::state());
		}
	));

	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state());
		}
	));

	_funcs.insert(std::make_pair("Slideback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_Slideback::state());
		}
	));

	_funcs.insert(std::make_pair("Ambush", 
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			std::tuple<unsigned int, unsigned char, unsigned int>* pData =
			reinterpret_cast<std::tuple<unsigned int, unsigned char, unsigned int>*>(in_data);
			in_enemy->pushAttack(
				std::get<0>(*pData), 
				std::get<1>(*pData),
				std::get<2>(*pData));
			return in_enemy->change(FSM_Enemy_Ambush::state());
		}
	));
}

//------------------------------------------------------------------------------
// �� ���� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Action::FSM_EnemyMsg_Action()
{
	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state());
		}
	));

	_funcs.insert(std::make_pair("Slideback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_Slideback::state());
		}
	));
}

//------------------------------------------------------------------------------
// �� �̵� ���� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Move::FSM_EnemyMsg_Move()
{
	_funcs.insert(std::make_pair("PlayHitting",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->shake();
			return true;
		}
	));

	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state(), true);
		}
	));

	_funcs.insert(std::make_pair("Slideback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool
	{
		in_enemy->setKnockbackPos(
			reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
		return in_enemy->change(FSM_Enemy_Slideback::state());
	}
	));
}

//------------------------------------------------------------------------------
// �� ���� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Attack::FSM_EnemyMsg_Attack()
{
	auto iter = _funcs.find("PlayAttack");
	iter->second = [](FSM_Enemy* in_enemy, void* in_data) -> bool {
			std::tuple<unsigned int, unsigned char, unsigned int>* pData =
			reinterpret_cast<std::tuple<unsigned int, unsigned char, unsigned int>*>(in_data);
			in_enemy->pushAttack(
				std::get<0>(*pData), 
				std::get<1>(*pData),
				std::get<2>(*pData));
			return in_enemy->change(FSM_Enemy_PlayAttackChanger::state());
	};
}

//------------------------------------------------------------------------------
// �� ��� ��� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_DieReady::FSM_EnemyMsg_DieReady()
{
	_funcs.insert(std::make_pair("PlayHitting",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			return in_enemy->change(FSM_Enemy_Die::state());
		}
	));
}

//------------------------------------------------------------------------------
// �÷��̾� ��� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Die::FSM_EnemyMsg_Die()
{
	_funcs.insert(std::make_pair("Revive",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setPosition(*static_cast<hkvVec3*>(in_data));
			return in_enemy->change(FSM_Enemy_Rivive::state(), true);
		}
	));
}


//------------------------------------------------------------------------------
// �� �˹� ���� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_BaseKnockback::FSM_EnemyMsg_BaseKnockback()
{
	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state());
	}
	));

	auto iter = _funcs.find("KnockbackDie");
	iter->second = [](FSM_Enemy* in_enemy, void* in_data) -> bool {
		return true;
	};

}
//------------------------------------------------------------------------------
// �� ���� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Stun::FSM_EnemyMsg_Stun()
{
	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state());
	}
	));

	_funcs.insert(std::make_pair("StunOff",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			void* state = in_enemy->getState(1) != nullptr ? 
				in_enemy->getState(1) : FSM_Enemy_Stand::state();
			return in_enemy->change(state);
		}
	));

	_funcs.insert(std::make_pair("Slideback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_Slideback::state());
		}
	));

	_funcs.insert(std::make_pair("PlayHitting",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->shake();
			return true;
	}
	));
}

//------------------------------------------------------------------------------
// �� ���� �޽��� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Sleep::FSM_EnemyMsg_Sleep()
{
	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state());
	}
	));

	_funcs.insert(std::make_pair("SleepOff",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			void* state = in_enemy->getState(1) != nullptr ? 
				in_enemy->getState(1) : FSM_Enemy_Stand::state();
			return in_enemy->change(state);
		}
	));

	_funcs.insert(std::make_pair("Slideback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_Slideback::state());
		}
	));
}


//------------------------------------------------------------------------------
// �� �и� ���� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_BaseSlideback::FSM_EnemyMsg_BaseSlideback()
{
	_funcs.insert(std::make_pair("Knockback",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->setKnockbackState(3);
			in_enemy->setKnockbackPos(
				reinterpret_cast<std::pair<hkvVec3, hkvVec3>*>(in_data)->first);
			return in_enemy->change(FSM_Enemy_knockback::state());
	}
	));

	_funcs.insert(std::make_pair("PlayHitting",
		[](FSM_Enemy* in_enemy, void* in_data) -> bool {
			in_enemy->shake();
			return true;
	}
	));
}

//------------------------------------------------------------------------------
// �� ���� ���� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_JumpAttack::FSM_EnemyMsg_JumpAttack()
{
	auto iter = _funcs.find("JumpAttack");
	iter->second = [](FSM_Enemy* in_enemy, void* in_data) -> bool {
		hkvVec3 jump_to_pos = *reinterpret_cast<hkvVec3*>(in_data);
		in_enemy->setMoveToPos(jump_to_pos);
		in_enemy->change(FSM_Enemy_JumpAttack::state());
		return true;
	};
}

FSM_EnemyMsg_LandingAttack::FSM_EnemyMsg_LandingAttack()
{

}

//------------------------------------------------------------------------------
// �� �ź� ���� ó�� Ŭ����
//------------------------------------------------------------------------------
FSM_EnemyMsg_Ambush::FSM_EnemyMsg_Ambush()
{
	auto iter = _funcs.find("Ambush");
	iter->second = [](FSM_Enemy* in_enemy, void* in_data) -> bool {
		std::tuple<unsigned int, unsigned char, unsigned int>* pData =
		reinterpret_cast<std::tuple<unsigned int, unsigned char, unsigned int>*>(in_data);
		in_enemy->pushAttack(
			std::get<0>(*pData), 
			std::get<1>(*pData),
			std::get<2>(*pData));
		in_enemy->change(FSM_Enemy_Ambush::state());
		return true;
	};
}