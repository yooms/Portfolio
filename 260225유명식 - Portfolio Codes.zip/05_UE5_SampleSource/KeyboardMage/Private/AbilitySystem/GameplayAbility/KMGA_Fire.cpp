#include "AbilitySystem/GameplayAbility/KMGA_Fire.h"
#include "AbilitySystem/GameplayState/KMPlayerState.h"
#include "Projectile/KMProjectile.h"
#include "Character/KMCharacter.h"
#include "Math/UnrealMathUtility.h"

UKMGA_Fire::UKMGA_Fire()
{
    NetExecutionPolicy = EGameplayAbilityNetExecutionPolicy::ServerOnly;
    InstancingPolicy = EGameplayAbilityInstancingPolicy::InstancedPerActor;
}

void UKMGA_Fire::ActivateAbility(
    const FGameplayAbilitySpecHandle Handle,
    const FGameplayAbilityActorInfo* ActorInfo,
    const FGameplayAbilityActivationInfo ActivationInfo,
    const FGameplayEventData* TriggerEventData)
{
    AKMCharacter* KMChar = Cast<AKMCharacter>(ActorInfo->AvatarActor.Get());
    if (!KMChar)
    {
        EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
        return;
    }

    if (!CommitAbility(Handle, ActorInfo, ActivationInfo))
    {
        EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
        return;
    }

    SpawnProjectile(ActorInfo);

    if (AKMPlayerState* PS = KMChar->GetPlayerState<AKMPlayerState>())
    {
        PS->ConsumeAndRequestNew();
    }

    EndAbility(Handle, ActorInfo, ActivationInfo, true, false);
}

void UKMGA_Fire::SpawnProjectile(const FGameplayAbilityActorInfo* ActorInfo)
{
    if (!ProjectileClass)
    {
        UE_LOG(LogTemp, Error, TEXT("[KM] KMGA_Fire: ProjectileClass NULL — BP_GA_Fire 에 ProjectileClass 를 설정하세요"));
        return;
    }

    AKMCharacter* KMChar = Cast<AKMCharacter>(ActorInfo->AvatarActor.Get());
    if (!KMChar) return;

    UWorld* World = KMChar->GetWorld();
    if (!World) return;

    const FVector MuzzleLoc = KMChar->GetMesh() && KMChar->GetMesh()->DoesSocketExist(TEXT("Muzzle"))) ? 
    KMChar->GetMesh()->GetSocketLocation(TEXT("Muzzle")) : KMChar->GetActorLocation() + KMChar->GetActorForwardVector() * 100.f;

    FVector AimPt = KMChar->GetReplicatedAimPoint();
    if (AimPt.IsZero())
    {
        AimPt = MuzzleLoc + KMChar->GetActorForwardVector() * 15000.f;
    }

    FVector BaseDir = (AimPt - MuzzleLoc).GetSafeNormal();
    if (BaseDir.IsNearlyZero())
    {
        BaseDir = KMChar->GetActorForwardVector();
    }

    const float SpreadDeg = KMChar->IsAim() ? AimSpreadDegrees : HipFireSpreadDegrees;
    const FVector ShootDir = ApplySpread(BaseDir, SpreadDeg);

    FActorSpawnParameters Params;
    Params.Owner = KMChar;
    Params.Instigator = KMChar;
    Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    AKMProjectile* Proj = World->SpawnActor<AKMProjectile>(ProjectileClass, MuzzleLoc, ShootDir.Rotation(), Params);

    if (Proj)
    {
        Proj->SetSourceASC(GetAbilitySystemComponentFromActorInfo());
        UE_LOG(LogTemp, Log, TEXT("[KM] KMGA_Fire: 발사체 스폰 성공 → %s"), *Proj->GetName());
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("[KM] KMGA_Fire: SpawnActor 실패"));
    }
}

FVector UKMGA_Fire::ApplySpread(const FVector& BaseDir, float SpreadDeg) const
{
    if (SpreadDeg <= KINDA_SMALL_NUMBER) return BaseDir;

    const float HalfAngleRad = FMath::DegreesToRadians(SpreadDeg);
    const float CosAngle = FMath::RandRange(FMath::Cos(HalfAngleRad), 1.f);
    const float SinAngle = FMath::Sqrt(1.f - CosAngle * CosAngle);
    const float RandomPhi = FMath::RandRange(0.f, 2.f * PI);

    FVector Up, Right;
    BaseDir.FindBestAxisVectors(Up, Right);

    return (BaseDir * CosAngle + Right   * (SinAngle * FMath::Cos(RandomPhi)) + Up * (SinAngle * FMath::Sin(RandomPhi))).GetSafeNormal();
}
