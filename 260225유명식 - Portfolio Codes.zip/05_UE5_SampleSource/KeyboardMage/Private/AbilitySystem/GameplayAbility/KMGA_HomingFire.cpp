#include "AbilitySystem/GameplayAbility/KMGA_HomingFire.h"
#include "Projectile/KMHomingProjectile.h"
#include "Character/KMCharacter.h"
#include "GameFramework/PlayerController.h"

UKMGA_HomingFire::UKMGA_HomingFire()
{
	NetExecutionPolicy = EGameplayAbilityNetExecutionPolicy::LocalPredicted;
	InstancingPolicy = EGameplayAbilityInstancingPolicy::InstancedPerActor;
}

void UKMGA_HomingFire::ActivateAbility(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo,
	const FGameplayEventData* TriggerEventData)
{
	if (!CommitAbility(Handle, ActorInfo, ActivationInfo))
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		return;
	}

	if (ActorInfo && ActorInfo->AvatarActor.IsValid() && ActorInfo->AvatarActor->HasAuthority())
	{
		AKMCharacter* KMChar = Cast<AKMCharacter>(ActorInfo->AvatarActor.Get());
		if (KMChar)
		{
			USceneComponent* Target = FindLockOnTarget(KMChar);
			SpawnHomingProjectile(ActorInfo, Target);
		}
	}

	EndAbility(Handle, ActorInfo, ActivationInfo, true, false);
}

USceneComponent* UKMGA_HomingFire::FindLockOnTarget(AKMCharacter* KMChar) const
{
	if (!KMChar)
	{
		return nullptr;
	}

	FVector TraceStart = KMChar->GetReplicatedCameraLocation();
	FVector WorldDir   = KMChar->GetReplicatedCameraRotation().Vector();

	if (TraceStart.IsZero())
	{
		TraceStart = KMChar->GetActorLocation();
		WorldDir   = KMChar->GetActorForwardVector();
	}

	const FVector TraceEnd = TraceStart + WorldDir * LockOnRange;

	TArray<FHitResult> Hits;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(KMChar);

	bool bHit = KMChar->GetWorld()->SweepMultiByChannel(
		Hits,
		TraceStart,
		TraceEnd,
		FQuat::Identity,
		EnemyChannel,
		FCollisionShape::MakeSphere(LockOnRadius),
		Params);

	if (!bHit || Hits.Num() == 0)
	{
		return nullptr;
	}

	float MinDist = MAX_FLT;
	AActor* BestActor = nullptr;
	for (const FHitResult& Hit : Hits)
	{
		if (!IsValid(Hit.GetActor()) || Hit.GetActor() == KMChar)
		{
			continue;
		}

		const float Dist = FVector::DistSquared(KMChar->GetActorLocation(), Hit.GetActor()->GetActorLocation());
		if (Dist < MinDist)
		{
			MinDist   = Dist;
			BestActor = Hit.GetActor();
		}
	}

	return BestActor ? BestActor->GetRootComponent() : nullptr;
}

void UKMGA_HomingFire::SpawnHomingProjectile(const FGameplayAbilityActorInfo* ActorInfo, USceneComponent* TargetComp)
{
	if (!HomingProjectileClass) 
		return;

	AKMCharacter* KMChar = Cast<AKMCharacter>(ActorInfo->AvatarActor.Get());
	if (!KMChar) 
		return;

	UWorld* World = KMChar->GetWorld();
	if (!World) 
		return;

	FVector MuzzleLoc = KMChar->GetMesh() && KMChar->GetMesh()->DoesSocketExist(TEXT("Muzzle")) ? 
		KMChar->GetMesh()->GetSocketLocation(TEXT("Muzzle")) : KMChar->GetActorLocation() + KMChar->GetActorForwardVector() * 100.f;

	FVector ShootDir;
	if (TargetComp)
	{
		ShootDir = (TargetComp->GetComponentLocation() - MuzzleLoc).GetSafeNormal();
	}
	else
	{
		FVector AimPt = KMChar->GetReplicatedAimPoint();
		ShootDir = (!AimPt.IsZero() && !AimPt.Equals(MuzzleLoc, 1.f)) ? 
			(AimPt - MuzzleLoc).GetSafeNormal() : KMChar->GetActorForwardVector();
	}

	FActorSpawnParameters Params;
	Params.Owner = KMChar;
	Params.Instigator = KMChar;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	AKMHomingProjectile* Proj = World->SpawnActor<AKMHomingProjectile>(HomingProjectileClass, MuzzleLoc, ShootDir.Rotation(), Params);

	if (Proj)
	{
		Proj->SetSourceASC(GetAbilitySystemComponentFromActorInfo());
		Proj->SetHomingTarget(TargetComp);
	}
}
