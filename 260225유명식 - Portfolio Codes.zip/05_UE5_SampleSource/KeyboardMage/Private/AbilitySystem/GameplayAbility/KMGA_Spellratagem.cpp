#include "AbilitySystem/GameplayAbility/KMGA_Spellratagem.h"
#include "Character/KMCharacter.h"

UKMGA_Spellratagem::UKMGA_Spellratagem()
{
    NetExecutionPolicy = EGameplayAbilityNetExecutionPolicy::LocalOnly;
    InstancingPolicy = EGameplayAbilityInstancingPolicy::InstancedPerActor;
}

void UKMGA_Spellratagem::ActivateAbility(
    const FGameplayAbilitySpecHandle Handle,
    const FGameplayAbilityActorInfo* ActorInfo,
    const FGameplayAbilityActivationInfo ActivationInfo,
    const FGameplayEventData* TriggerEventData)
{
    if (!CommitAbility(Handle, ActorInfo, ActivationInfo))
    {
        EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
        return;
    }

    UE_LOG(LogTemp, Warning, TEXT("[KM] 커맨드 입력 모드 시작 (%.1f초)"), CommandTimeout);

    if (CommandTimeout > 0.f)
    {
        if (ActorInfo && ActorInfo->AvatarActor.IsValid())
        {
            if (UWorld* World = ActorInfo->AvatarActor->GetWorld())
            {
                World->GetTimerManager().SetTimer(TimeoutHandle, this, &UKMGA_Spellratagem::OnTimeout, CommandTimeout, false);
            }
        }
    }
}

void UKMGA_Spellratagem::NotifyCommandSuccess()
{
    UE_LOG(LogTemp, Warning, TEXT("[KM] 커맨드 성공 → 입력 모드 종료"));

    EndAbility(
        GetCurrentAbilitySpecHandle(),
        GetCurrentActorInfo(),
        GetCurrentActivationInfo(),
        true, false);
}

void UKMGA_Spellratagem::OnTimeout()
{
    UE_LOG(LogTemp, Warning, TEXT("[KM] 타임아웃 → 입력 모드 종료"));

    EndAbility(
        GetCurrentAbilitySpecHandle(),
        GetCurrentActorInfo(),
        GetCurrentActivationInfo(),
        true, true);
}

void UKMGA_Spellratagem::EndAbility(
    const FGameplayAbilitySpecHandle Handle,
    const FGameplayAbilityActorInfo* ActorInfo,
    const FGameplayAbilityActivationInfo ActivationInfo,
    bool bReplicateEndAbility,
    bool bWasCancelled)
{
    if (ActorInfo && ActorInfo->AvatarActor.IsValid())
    {
        if (UWorld* World = ActorInfo->AvatarActor->GetWorld())
        {
            World->GetTimerManager().ClearTimer(TimeoutHandle);
        }
    }

    Super::EndAbility(Handle, ActorInfo, ActivationInfo, bReplicateEndAbility, bWasCancelled);
}
