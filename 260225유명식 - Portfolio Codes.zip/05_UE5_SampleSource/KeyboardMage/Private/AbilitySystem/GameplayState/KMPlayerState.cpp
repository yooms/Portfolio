#include "AbilitySystem/GameplayState/KMPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "GameMode/KMGameMode.h"

AKMPlayerState::AKMPlayerState()
{
}

void AKMPlayerState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(AKMPlayerState, CurrentCommand);
    DOREPLIFETIME(AKMPlayerState, bCommandReady);
}

void AKMPlayerState::SetCommand(const FStratagemCommand& NewCommand)
{
    CurrentCommand = NewCommand;
    bCommandReady  = false;

    OnRep_CurrentCommand();
    OnRep_CommandReady();
}

void AKMPlayerState::ConsumeAndRequestNew()
{
    bCommandReady = false;
    OnRep_CommandReady();

    if (UWorld* World = GetWorld())
    {
        if (AKMGameMode* GM = Cast<AKMGameMode>(World->GetAuthGameMode()))
        {
            GM->AssignRandomCommand(this);
        }
    }
}

void AKMPlayerState::Server_SubmitCommand_Implementation(
    const TArray<EKMCommandDirection>& InputSequence)
{
    const bool bMatch = CurrentCommand.Matches(InputSequence);

    UE_LOG(LogTemp, Warning, TEXT("[KM] Server_SubmitCommand - Match:%d (%d/%d inputs)"), (int)bMatch, InputSequence.Num(), CurrentCommand.Inputs.Num());

    bCommandReady = bMatch;

    OnRep_CommandReady();
}

void AKMPlayerState::OnRep_CurrentCommand()
{
    OnCommandChanged.Broadcast(CurrentCommand);

    FString Seq;
    for (EKMCommandDirection D : CurrentCommand.Inputs)
    {
        Seq += (D == EKMCommandDirection::Up)   ? TEXT("↑") :
               (D == EKMCommandDirection::Down)  ? TEXT("↓") :
               (D == EKMCommandDirection::Left)  ? TEXT("←") : TEXT("→");
        Seq += TEXT(" ");
    }
    UE_LOG(LogTemp, Warning, TEXT("[KM] New Command: [ %s]"), *Seq);
}

void AKMPlayerState::OnRep_CommandReady()
{
    OnCommandResult.Broadcast(bCommandReady);
    UE_LOG(LogTemp, Warning, TEXT("[KM] CommandReady: %s"), bCommandReady ? TEXT("발사가능") : TEXT("커맨드"));
}
