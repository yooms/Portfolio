#include "AbilitySystem/GameplayTags/KMGameplayTags.h"
#include "GameplayTagsManager.h"

FGameplayTag KMGameplayTags::Ability_Fire;
FGameplayTag KMGameplayTags::Ability_Aim;
FGameplayTag KMGameplayTags::Ability_Jump;
FGameplayTag KMGameplayTags::Ability_Roll;
FGameplayTag KMGameplayTags::Ability_HomingFire;
FGameplayTag KMGameplayTags::State_Aiming;
FGameplayTag KMGameplayTags::State_Rolling;
FGameplayTag KMGameplayTags::State_Invincible;
FGameplayTag KMGameplayTags::State_InAir;
FGameplayTag KMGameplayTags::Block_Movement;
FGameplayTag KMGameplayTags::Event_Fire;

void KMGameplayTags::InitTags()
{
    UGameplayTagsManager& Mgr = UGameplayTagsManager::Get();

    Ability_Fire       = Mgr.AddNativeGameplayTag(TEXT("Character.Projectile.BasicSkill"));
    Ability_Aim        = Mgr.AddNativeGameplayTag(TEXT("Character.Sight"));
    Ability_Jump       = Mgr.AddNativeGameplayTag(TEXT("Character.Motion.Jump"));
    Ability_Roll       = Mgr.AddNativeGameplayTag(TEXT("Character.Motion.Roll"));
    Ability_HomingFire = Mgr.AddNativeGameplayTag(TEXT("Character.Projectile.Homing"));

    State_Aiming       = Mgr.AddNativeGameplayTag(TEXT("Character.State.Aiming"));
    State_Rolling      = Mgr.AddNativeGameplayTag(TEXT("Character.State.Rolling"));
    State_Invincible   = Mgr.AddNativeGameplayTag(TEXT("Character.State.Invincible"));
    State_InAir        = Mgr.AddNativeGameplayTag(TEXT("Character.State.InAir"));

    Block_Movement     = Mgr.AddNativeGameplayTag(TEXT("Character.Block.Movement"));
    Event_Fire         = Mgr.AddNativeGameplayTag(TEXT("Character.Event.Fire"));
}
