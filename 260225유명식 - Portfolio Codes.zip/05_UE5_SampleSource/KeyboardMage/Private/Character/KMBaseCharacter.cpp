#include "Character/KMBaseCharacter.h"
#include "Net/UnrealNetwork.h"
#include "AbilitySystem/GameplayState/KMCharacterState.h"
#include "AbilitySystem/GameplayTags/KMGameplayTags.h"
#include "AbilitySystem/GameplayAttributeSet/KMCharacterAttributeSet.h"
#include "AbilitySystemComponent.h"

DEFINE_LOG_CATEGORY(LogTemplateCharacter);

AKMBaseCharacter::AKMBaseCharacter()
{
    TrajectoryComponent = CreateDefaultSubobject<UCharacterTrajectoryComponent>("CharacterTrajectoryComponent");
    bReplicates = true;
    SetReplicateMovement(true);
    PrimaryActorTick.bCanEverTick = true;
}

UAbilitySystemComponent* AKMBaseCharacter::GetAbilitySystemComponent() const
{
    return AbilitySystemComponent;
}

void AKMBaseCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}

void AKMBaseCharacter::InitAbilitySystem()
{
    AKMCharacterState* KMCharacterState = GetPlayerState<AKMCharacterState>();
    if (!KMCharacterState) 
        return;

    AbilitySystemComponent = KMCharacterState->GetAbilitySystemComponent();
    if (!AbilitySystemComponent) 
        return;

    AbilitySystemComponent->InitAbilityActorInfo(KMCharacterState, this);

    if (HasAuthority() && !bAbilitiesGiven)
    {
        GiveDefaultAbilities();
        bAbilitiesGiven = true;
    }
}

void AKMBaseCharacter::GiveDefaultAbilities()
{
    if (!AbilitySystemComponent) 
        return;

    if (DefaultAbilities.Num() == 0)
    {
        return;
    }

    for (TSubclassOf<UGameplayAbility> AbilityClass : DefaultAbilities)
    {
        if (!AbilityClass) 
            continue;

        FGameplayAbilitySpec Spec(AbilityClass, 1);
        AbilitySystemComponent->GiveAbility(Spec);

        UE_LOG(LogTemp, Warning, TEXT("[KM] GiveAbility: %s"), *AbilityClass->GetName());
    }

    UE_LOG(LogTemp, Warning, TEXT("[KM] GiveDefaultAbilities DONE - Total: %d"), AbilitySystemComponent->GetActivatableAbilities().Num());
}

void AKMBaseCharacter::PossessedBy(AController* NewController)
{
    Super::PossessedBy(NewController);
    InitAbilitySystem();
}

void AKMBaseCharacter::OnRep_PlayerState()
{
    Super::OnRep_PlayerState();
    InitAbilitySystem();
}
