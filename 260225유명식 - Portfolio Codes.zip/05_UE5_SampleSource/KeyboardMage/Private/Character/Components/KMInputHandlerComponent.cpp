#include "Character/Components/KMInputHandlerComponent.h"
#include "EnhancedInputComponent.h"
#include "Character/KMCharacter.h"
#include "AbilitySystemComponent.h"
#include "AbilitySystem/GameplayAbility/KMGA_Spellratagem.h"
#include "AbilitySystem/GameplayAbility/KMGA_Fire.h"
#include "AbilitySystem/GameplayAbility/KMGA_Jump.h"
#include "AbilitySystem/GameplayAbility/KMGA_Roll.h"
#include "AbilitySystem/GameplayAbility/KMGA_Aim.h"
#include "AbilitySystem/GameplayAbility/KMGA_HomingFire.h"
#include "AbilitySystem/GameplayState/KMPlayerState.h"
#include "KeyboardMage/KeyboardMage.h"

void UKMInputHandlerComponent::Initialize(UEnhancedInputComponent* InputComp, AKMCharacter* InOwner)
{
    OwnerCharacter = InOwner;
    if (!InputComp) return;

    InputComp->BindAction(MoveAction,      ETriggerEvent::Triggered, this, &UKMInputHandlerComponent::Move);
    InputComp->BindAction(LookAction,      ETriggerEvent::Triggered, this, &UKMInputHandlerComponent::Look);
    InputComp->BindAction(MouseLookAction, ETriggerEvent::Triggered, this, &UKMInputHandlerComponent::Look);

    if (JumpAction)
    {
        InputComp->BindAction(JumpAction, ETriggerEvent::Started,   this, &UKMInputHandlerComponent::JumpStart);
        InputComp->BindAction(JumpAction, ETriggerEvent::Completed, this, &UKMInputHandlerComponent::JumpEnd);
    }

    InputComp->BindAction(CommandUpAction,    ETriggerEvent::Started, this, &UKMInputHandlerComponent::Up);
    InputComp->BindAction(CommandDownAction,  ETriggerEvent::Started, this, &UKMInputHandlerComponent::Down);
    InputComp->BindAction(CommandLeftAction,  ETriggerEvent::Started, this, &UKMInputHandlerComponent::Left);
    InputComp->BindAction(CommandRightAction, ETriggerEvent::Started, this, &UKMInputHandlerComponent::Right);

    if (FireAction)
        InputComp->BindAction(FireAction, ETriggerEvent::Started, this, &UKMInputHandlerComponent::Fire);

    if (AimAction)
    {
        InputComp->BindAction(AimAction, ETriggerEvent::Started,   this, &UKMInputHandlerComponent::AimPressed);
        InputComp->BindAction(AimAction, ETriggerEvent::Completed, this, &UKMInputHandlerComponent::AimReleased);
    }

    if (RollAction)
        InputComp->BindAction(RollAction, ETriggerEvent::Started, this, &UKMInputHandlerComponent::Roll);

    if (HomingFireAction)
        InputComp->BindAction(HomingFireAction, ETriggerEvent::Started, this, &UKMInputHandlerComponent::HomingFire);
}

void UKMInputHandlerComponent::TryActivateAbilityByClass(TSubclassOf<UGameplayAbility> AbilityClass)
{
    if (!IsValid(OwnerCharacter)) return;
    UAbilitySystemComponent* ASC = OwnerCharacter->GetAbilitySystemComponent();
    if (!ASC) return;

    for (const FGameplayAbilitySpec& Spec : ASC->GetActivatableAbilities())
    {
        if (Spec.Ability && Spec.Ability->GetClass()->IsChildOf(AbilityClass))
        {
            ASC->TryActivateAbility(Spec.Handle);
            return;
        }
    }

    UE_LOG(LogTemp, Warning, TEXT("[KM] TryActivateAbilityByClass: %s not found (Abilities:%d)"),
        *AbilityClass->GetName(), ASC->GetActivatableAbilities().Num());
}

void UKMInputHandlerComponent::SendAbilityInputReleased(TSubclassOf<UGameplayAbility> AbilityClass)
{
    if (!IsValid(OwnerCharacter)) return;
    UAbilitySystemComponent* ASC = OwnerCharacter->GetAbilitySystemComponent();
    if (!ASC) return;

    for (FGameplayAbilitySpec& Spec : ASC->GetActivatableAbilities())
    {
        if (Spec.Ability && Spec.Ability->GetClass()->IsChildOf(AbilityClass) && Spec.IsActive())
        {
            ASC->AbilitySpecInputReleased(Spec);
            return;
        }
    }
}

void UKMInputHandlerComponent::JumpStart() { TryActivateAbilityByClass(UKMGA_Jump::StaticClass()); }
void UKMInputHandlerComponent::JumpEnd()   { SendAbilityInputReleased(UKMGA_Jump::StaticClass()); }

void UKMInputHandlerComponent::Move(const FInputActionValue& Value)
{
    if (!IsValid(OwnerCharacter)) return;
    FVector2D V = Value.Get<FVector2D>();
    OwnerCharacter->DoMove(V.X, V.Y);
}

void UKMInputHandlerComponent::Look(const FInputActionValue& Value)
{
    if (!IsValid(OwnerCharacter)) return;
    FVector2D V = Value.Get<FVector2D>();
    OwnerCharacter->DoLook(V.X, V.Y);
}

void UKMInputHandlerComponent::Fire()
{
    TryActivateAbilityByClass(UKMGA_Fire::StaticClass());
}

void UKMInputHandlerComponent::AimPressed()  { TryActivateAbilityByClass(UKMGA_Aim::StaticClass()); }
void UKMInputHandlerComponent::AimReleased() { SendAbilityInputReleased(UKMGA_Aim::StaticClass()); }
void UKMInputHandlerComponent::Roll()        { TryActivateAbilityByClass(UKMGA_Roll::StaticClass()); }
void UKMInputHandlerComponent::HomingFire()  { TryActivateAbilityByClass(UKMGA_HomingFire::StaticClass()); }

// ─────────────────────────────────────────────────────────────────────────────
//  화살표 커맨드 입력
// ─────────────────────────────────────────────────────────────────────────────

void UKMInputHandlerComponent::Up(const FInputActionValue& Value)
{
    UE_LOG(LogKeyboardMage, Verbose, TEXT("Command ↑"));
    AddInput(EKMCommandDirection::Up);
}
void UKMInputHandlerComponent::Down(const FInputActionValue& Value)
{
    UE_LOG(LogKeyboardMage, Verbose, TEXT("Command ↓"));
    AddInput(EKMCommandDirection::Down);
}
void UKMInputHandlerComponent::Right(const FInputActionValue& Value)
{
    UE_LOG(LogKeyboardMage, Verbose, TEXT("Command →"));
    AddInput(EKMCommandDirection::Right);
}
void UKMInputHandlerComponent::Left(const FInputActionValue& Value)
{
    UE_LOG(LogKeyboardMage, Verbose, TEXT("Command ←"));
    AddInput(EKMCommandDirection::Left);
}

void UKMInputHandlerComponent::AddInput(EKMCommandDirection Dir)
{
    InputBuffer.Add(Dir);

    if (UWorld* World = GetWorld())
    {
        World->GetTimerManager().ClearTimer(ResetTimer);
        World->GetTimerManager().SetTimer(
            ResetTimer, this,
            &UKMInputHandlerComponent::ClearInput,
            InputResetTime, false);
    }

    EvaluateCommand();
}

void UKMInputHandlerComponent::ClearInput()
{
    InputBuffer.Empty();
}

void UKMInputHandlerComponent::EvaluateCommand()
{
    if (!IsValid(OwnerCharacter)) return;

    AKMPlayerState* PS = OwnerCharacter->GetPlayerState<AKMPlayerState>();
    if (!PS || PS->CurrentCommand.IsEmpty()) return;

    const int32 RequiredLen = PS->CurrentCommand.Inputs.Num();
    if (InputBuffer.Num() < RequiredLen) return;

    TArray<EKMCommandDirection> LastN;
    for (int32 i = InputBuffer.Num() - RequiredLen; i < InputBuffer.Num(); i++)
        LastN.Add(InputBuffer[i]);

    if (PS->CurrentCommand.Matches(LastN))
    {
        InputBuffer.Empty();
        UE_LOG(LogTemp, Warning, TEXT("[KM] Command matched! 서버로 전송..."));

        PS->Server_SubmitCommand(LastN);

        NotifySpellratagemSuccess();
    }
}

void UKMInputHandlerComponent::NotifySpellratagemSuccess()
{
    if (!IsValid(OwnerCharacter)) return;
    UAbilitySystemComponent* ASC = OwnerCharacter->GetAbilitySystemComponent();
    if (!ASC) return;

    for (FGameplayAbilitySpec& Spec : ASC->GetActivatableAbilities())
    {
        if (Spec.Ability &&
            Spec.Ability->GetClass()->IsChildOf(UKMGA_Spellratagem::StaticClass()) &&
            Spec.IsActive())
        {
            if (UKMGA_Spellratagem* GA = Cast<UKMGA_Spellratagem>(Spec.GetPrimaryInstance()))
            {
                GA->NotifyCommandSuccess();
            }
            break;
        }
    }
}

void UKMInputHandlerComponent::TryActivateAbilityByInputID(uint8 InputID) {}
void UKMInputHandlerComponent::SendInputReleasedByInputID(uint8 InputID) {}
