#pragma once
#include "CoreMinimal.h"
#include "GameplayTagContainer.h"



struct KEYBOARDMAGE_API KMGameplayTags
{
    static FGameplayTag Ability_Fire;        // Character.Projectile.BasicSkill
    static FGameplayTag Ability_Aim;         // Character.Sight
    static FGameplayTag Ability_Jump;        // Character.Motion.Jump
    static FGameplayTag Ability_Roll;        // Character.Motion.Roll
    static FGameplayTag Ability_HomingFire;  // Character.Projectile.Homing

    static FGameplayTag State_Aiming;        // Character.State.Aiming
    static FGameplayTag State_Rolling;       // Character.State.Rolling
    static FGameplayTag State_Invincible;    // Character.State.Invincible
    static FGameplayTag State_InAir;         // Character.State.InAir

    static FGameplayTag Block_Movement;      // Character.Block.Movement

    static FGameplayTag Event_Fire;          // Character.Event.Fire

    static void InitTags();
};
