#pragma once
#include "CoreMinimal.h"
#include "AbilitySystem/GameplayAbility/KMCharacterGameplayAbility.h"
#include "KMGA_HomingFire.generated.h"


UCLASS()
class KEYBOARDMAGE_API UKMGA_HomingFire : public UKMCharacterGameplayAbility
{
	GENERATED_BODY()
public:
	UKMGA_HomingFire();

	UPROPERTY(EditDefaultsOnly, Category="Combat")
	TSubclassOf<class AKMHomingProjectile> HomingProjectileClass;

	UPROPERTY(EditDefaultsOnly, Category="Combat", meta=(ClampMin="100.0"))
	float LockOnRange = 3000.f;

	UPROPERTY(EditDefaultsOnly, Category="Combat", meta=(ClampMin="10.0"))
	float LockOnRadius = 200.f;

	UPROPERTY(EditDefaultsOnly, Category="Combat")
	TEnumAsByte<ECollisionChannel> EnemyChannel = ECC_Pawn;

public:
	virtual void ActivateAbility(
		const FGameplayAbilitySpecHandle Handle,
		const FGameplayAbilityActorInfo* ActorInfo,
		const FGameplayAbilityActivationInfo ActivationInfo,
		const FGameplayEventData* TriggerEventData) override;

private:
	USceneComponent* FindLockOnTarget(AKMCharacter* KMChar) const;

	void SpawnHomingProjectile(const FGameplayAbilityActorInfo* ActorInfo, USceneComponent* TargetComp);
};
