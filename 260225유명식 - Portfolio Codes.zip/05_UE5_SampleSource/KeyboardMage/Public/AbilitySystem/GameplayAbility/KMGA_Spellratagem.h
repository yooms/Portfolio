#pragma once

#include "CoreMinimal.h"
#include "AbilitySystem/GameplayAbility/KMCharacterGameplayAbility.h"
#include "KMGA_Spellratagem.generated.h"


UCLASS()
class KEYBOARDMAGE_API UKMGA_Spellratagem : public UKMCharacterGameplayAbility
{
    GENERATED_BODY()
public:
    UKMGA_Spellratagem();

    UPROPERTY(EditDefaultsOnly, Category="Command", meta=(ClampMin="0.0"))
    float CommandTimeout = 5.0f;

public:
    virtual void ActivateAbility(
        const FGameplayAbilitySpecHandle Handle,
        const FGameplayAbilityActorInfo* ActorInfo,
        const FGameplayAbilityActivationInfo ActivationInfo,
        const FGameplayEventData* TriggerEventData) override;

    virtual void EndAbility(
        const FGameplayAbilitySpecHandle Handle,
        const FGameplayAbilityActorInfo* ActorInfo,
        const FGameplayAbilityActivationInfo ActivationInfo,
        bool bReplicateEndAbility,
        bool bWasCancelled) override;

    void NotifyCommandSuccess();

private:
    FTimerHandle TimeoutHandle;
    void OnTimeout();
};
