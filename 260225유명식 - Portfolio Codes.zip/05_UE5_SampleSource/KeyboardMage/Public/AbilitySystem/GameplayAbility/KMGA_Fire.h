#pragma once

#include "CoreMinimal.h"
#include "AbilitySystem/GameplayAbility/KMCharacterGameplayAbility.h"
#include "KMGA_Fire.generated.h"



UCLASS()
class KEYBOARDMAGE_API UKMGA_Fire : public UKMCharacterGameplayAbility
{
    GENERATED_BODY()
public:
    UKMGA_Fire();

    UPROPERTY(EditDefaultsOnly, Category="Combat")
    TSubclassOf<class AKMProjectile> ProjectileClass;

    UPROPERTY(EditDefaultsOnly, Category="Combat|Spread", meta=(ClampMin="0.0", ClampMax="45.0"))
    float HipFireSpreadDegrees = 5.0f;

    UPROPERTY(EditDefaultsOnly, Category="Combat|Spread", meta=(ClampMin="0.0", ClampMax="10.0"))
    float AimSpreadDegrees = 0.5f;

public:
    virtual void ActivateAbility(
        const FGameplayAbilitySpecHandle Handle,
        const FGameplayAbilityActorInfo* ActorInfo,
        const FGameplayAbilityActivationInfo ActivationInfo,
        const FGameplayEventData* TriggerEventData) override;

private:
    void SpawnProjectile(const FGameplayAbilityActorInfo* ActorInfo);
    FVector ApplySpread(const FVector& BaseDir, float SpreadDeg) const;
};
