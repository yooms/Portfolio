#pragma once

#include "CoreMinimal.h"
#include "AbilitySystem/GameplayState/KMCharacterState.h"
#include "Common/KMSpellratagemTypes.h"
#include "KMPlayerState.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCommandChanged, const FStratagemCommand&, NewCommand);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCommandResult,  bool, bSuccess);

UCLASS()
class KEYBOARDMAGE_API AKMPlayerState : public AKMCharacterState
{
    GENERATED_BODY()

public:
    AKMPlayerState();

    UPROPERTY(ReplicatedUsing=OnRep_CurrentCommand, BlueprintReadOnly, Category="Stratagem")
    FStratagemCommand CurrentCommand;

    UPROPERTY(ReplicatedUsing=OnRep_CommandReady, BlueprintReadOnly, Category="Stratagem")
    bool bCommandReady = false;

    UPROPERTY(BlueprintAssignable, Category="Stratagem")
    FOnCommandChanged OnCommandChanged;

    UPROPERTY(BlueprintAssignable, Category="Stratagem")
    FOnCommandResult  OnCommandResult;

    void SetCommand(const FStratagemCommand& NewCommand);

    void ConsumeAndRequestNew();

    UFUNCTION(Server, Reliable)
    void Server_SubmitCommand(const TArray<EKMCommandDirection>& InputSequence);

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

private:
    UFUNCTION() void OnRep_CurrentCommand();
    UFUNCTION() void OnRep_CommandReady();
};
