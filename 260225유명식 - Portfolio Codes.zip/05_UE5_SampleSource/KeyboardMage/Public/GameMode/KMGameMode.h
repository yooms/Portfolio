#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "KMGameMode.generated.h"

UCLASS(abstract)
class KEYBOARDMAGE_API AKMGameMode : public AGameModeBase
{
    GENERATED_BODY()

public:
    AKMGameMode();

    virtual void PostLogin(APlayerController* NewPlayer) override;

    void AssignRandomCommand(class AKMPlayerState* PS);

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="Stratagem", meta=(ClampMin="1", ClampMax="8"))
    int32 CommandLength = 4;
};
