#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InputActionValue.h"
#include "Common/KMSpellratagemTypes.h"
#include "Abilities/GameplayAbility.h"
#include "KMInputHandlerComponent.generated.h"

class UInputAction;
class UEnhancedInputComponent;
class AKMCharacter;

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KEYBOARDMAGE_API UKMInputHandlerComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    void Initialize(UEnhancedInputComponent* InputComp, AKMCharacter* InOwner);

protected:
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* JumpAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* MoveAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* LookAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* MouseLookAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* CommandUpAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* CommandDownAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* CommandRightAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* CommandLeftAction;
    UPROPERTY(EditAnywhere, Category="Input") UInputAction* FireAction;
    UPROPERTY(EditAnywhere, Category="Input|New") UInputAction* AimAction;
    UPROPERTY(EditAnywhere, Category="Input|New") UInputAction* RollAction;
    UPROPERTY(EditAnywhere, Category="Input|New") UInputAction* HomingFireAction;

private:
    AKMCharacter* OwnerCharacter;
    TArray<EKMCommandDirection> InputBuffer;
    TArray<EKMCommandDirection> TargetSequence;

protected:
    UPROPERTY(EditDefaultsOnly) float InputResetTime = 1.0f;
    FTimerHandle ResetTimer;

public:
    void JumpStart();
    void JumpEnd();
    void Move(const FInputActionValue& Value);
    void Look(const FInputActionValue& Value);
    void Fire();
    void AimPressed();
    void AimReleased();
    void Roll();
    void HomingFire();
    void Up(const FInputActionValue& Value);
    void Down(const FInputActionValue& Value);
    void Right(const FInputActionValue& Value);
    void Left(const FInputActionValue& Value);
    void AddInput(EKMCommandDirection Dir);
    void ClearInput();
    void EvaluateCommand();

private:
    void TryActivateAbilityByClass(TSubclassOf<UGameplayAbility> AbilityClass);
    void SendAbilityInputReleased(TSubclassOf<UGameplayAbility> AbilityClass);

    void TryActivateAbilityByInputID(uint8 InputID);
    void SendInputReleasedByInputID(uint8 InputID);
    void NotifySpellratagemSuccess();
};
