#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "AbilitySystemInterface.h"
#include "AbilitySystemComponent.h"
#include "Animation/MotionMatchingComponent.h"
#include "Animation/MotionTrajectoryComponent.h"
#include "CharacterTrajectoryComponent.h"
#include "KMBaseCharacter.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogTemplateCharacter, Log, All);

UCLASS(Abstract)
class KEYBOARDMAGE_API AKMBaseCharacter : public ACharacter, public IAbilitySystemInterface
{
    GENERATED_BODY()

public:
    AKMBaseCharacter();

protected:
    UPROPERTY(EditAnywhere)
    TObjectPtr<class UAbilitySystemComponent> AbilitySystemComponent;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UCharacterTrajectoryComponent> TrajectoryComponent;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UMotionMatchingComponent> MotionMatchingComponent;

    bool bAbilitiesGiven = false;

public:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Abilities")
    TArray<TSubclassOf<class UGameplayAbility>> DefaultAbilities;

public:
    virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override;
    UCharacterTrajectoryComponent* GetCharacterTrajectoryComponent() const { return TrajectoryComponent; }

protected:
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
    virtual void PossessedBy(AController* NewController) override;
    virtual void OnRep_PlayerState() override;

    void InitAbilitySystem();
    virtual void GiveDefaultAbilities();
};
