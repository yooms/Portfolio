#include "KMServerSubsystem.h"
#include "Engine/Engine.h"


void UKMServerSubsystem::InitDatabase()
{
    UE_LOG(LogTemp, Warning, TEXT("Database Connected"));
}

void UKMServerSubsystem::StartMatchmaking()
{
    UE_LOG(LogTemp, Warning, TEXT("Matchmaking Started"));
}