#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "KMServerSubsystem.generated.h"

UCLASS()
class KEYBOARDMAGESERVER_API UKMServerSubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()


private:
    void InitDatabase();
    void StartMatchmaking();
};