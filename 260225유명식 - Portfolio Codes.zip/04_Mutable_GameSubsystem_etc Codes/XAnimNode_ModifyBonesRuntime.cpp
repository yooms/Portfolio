#include "AnimGraph/XAnimNode_ModifyBonesRuntime.h"
#include "Animation/AnimInstanceProxy.h"


// ---------------- FAnimNode_ModifyBonesRuntime ----------------
void FXAnimNode_ModifyBonesRuntime::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	FAnimNode_Base::Initialize_AnyThread(Context);
	ComponentPose.Initialize(Context);
}

void FXAnimNode_ModifyBonesRuntime::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context)
{
	FAnimNode_Base::CacheBones_AnyThread(Context);
	ComponentPose.CacheBones(Context);
	InitializeBoneReferences(Context.AnimInstanceProxy->GetRequiredBones());
}

void FXAnimNode_ModifyBonesRuntime::Update_AnyThread(const FAnimationUpdateContext& Context)
{
	GetEvaluateGraphExposedInputs().Execute(Context);
	ComponentPose.Update(Context);
}

void FXAnimNode_ModifyBonesRuntime::EvaluateComponentSpace_AnyThread(FComponentSpacePoseContext& Output)
{
	ComponentPose.EvaluateComponentSpace(Output);

	const FBoneContainer& BoneContainer = Output.Pose.GetPose().GetBoneContainer();
	const FTransform ComponentTransform = Output.AnimInstanceProxy->GetComponentTransform();

	FBoneReference BoneReference;
	FCompactPoseBoneIndex BoneIndex(INDEX_NONE);

	for (auto& Elem : BoneOffsets)
	{
		const FName BoneName = Elem.Key;
		const FXBoneOffsetData& Offset = Elem.Value;

		BoneReference.Reset();
		BoneReference.BoneName = BoneName;
		BoneReference.Initialize(BoneContainer);
		if (!BoneReference.IsValidToEvaluate(BoneContainer))
		{
			UE_LOG(LogTemp, Log, TEXT("Failed BoneRef.IsValidToEvaluate(BoneContainer): %s"), *(BoneName.ToString()));
			continue;
		}

		BoneIndex = BoneReference.GetCompactPoseIndex(BoneContainer);
		if (BoneIndex == INDEX_NONE)
		{
			UE_LOG(LogTemp, Log, TEXT("BoneIndex is Invalid: %s"), *(BoneName.ToString()));
			continue;
		}

		FTransform BoneTransform = Output.Pose.GetComponentSpaceTransform(BoneIndex);
		FAnimationRuntime::ConvertCSTransformToBoneSpace(ComponentTransform, Output.Pose, BoneTransform, BoneIndex, BCS_ParentBoneSpace);

		BoneTransform.AddToTranslation(Offset.Location);
		BoneTransform.SetRotation((Offset.Rotation + BoneTransform.GetRotation().Rotator()).Quaternion());
		BoneTransform.SetScale3D(Offset.Scale);

		FAnimationRuntime::ConvertBoneSpaceTransformToCS(ComponentTransform, Output.Pose, BoneTransform, BoneIndex, BCS_ParentBoneSpace);
		Output.Pose.LocalBlendCSBoneTransforms({ FBoneTransform(BoneIndex, BoneTransform) }, 1.0f);

//		UE_LOG(LogTemp, Log, TEXT("FAnimNode_ModifyBonesRuntime::EvaluateSkeletalControl_AnyThread::BoneName: %s || Offset.Location:: %s || Offset.Rotation:: %s || Offset.Scale:: %s"), *(BoneName.ToString()), *(Offset.Location.ToString()), *(Offset.Rotation.ToString()), *(Offset.Scale.ToString()));
	}
}