// Copyright Epic Games, Inc. All Rights Reserved.

#include "SoulEditor.h"
#include "Interfaces/IMainFrameModule.h"
#include "XSoulMenu.h"
#include "XSoulAction.h"
#include "XSoulToolbar.h"
#include "XAssetFixupRedirectorUtility.h"

IMPLEMENT_GAME_MODULE(FSoulEditorModule,SoulEditor);


void FSoulEditorModule::StartupModule()
{
// 	if(!IsRunningCommandlet())
// 	{
// 		for(auto Module : m_Module)
// 			Module->OnStartupModule();
// 	}
// 
// 	XSoulMenu::Register();
// 	XSoulAction::Register();
// 	XSoulToolbar::Register();

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FSoulEditorModule::RegisterMenus));
}

void FSoulEditorModule::ShutdownModule()
{
// 	XSoulMenu::Unregister();
// 	XSoulAction::Unregister();
// 	XSoulToolbar::Unregister();
// 
// 	for(auto Module : m_Module)
// 		Module->OnShutdownModule();
}

void FSoulEditorModule::RegisterMenus()
{
	UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");

	FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("PluginTools");
	Section.AddEntry(FToolMenuEntry::InitToolBarButton(
		"FixupRedirectors",
		FUIAction(FExecuteAction::CreateRaw(this, &FSoulEditorModule::OnClickFixupRedirectors)),
		NSLOCTEXT("SoulEditor", "FixupRedirectorsLabel", "Fix Redirects"),
		NSLOCTEXT("SoulEditor", "FixupRedirectorsTooltip", "Fix up asset redirectors"),
		FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Refresh")
	));
}

void FSoulEditorModule::OnClickFixupRedirectors()
{
	UXAssetFixupRedirectorUtility::FixupRedirectorsWithExclusion();
}