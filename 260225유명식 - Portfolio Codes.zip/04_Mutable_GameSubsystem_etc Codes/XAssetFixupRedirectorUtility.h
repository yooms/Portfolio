#pragma once

#include "CoreMinimal.h"
#include "XAssetFixupRedirectorUtility.generated.h"


UCLASS()
class UXAssetFixupRedirectorUtility : public UObject
{
    GENERATED_BODY()

public:
    static void FixupRedirectorsWithExclusion();
};