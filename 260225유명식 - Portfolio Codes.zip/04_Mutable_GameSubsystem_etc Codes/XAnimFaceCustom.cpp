#include "Anim/XAnimFaceCustom.h"


// ---------------- UXCharacterFaceCustomAnimInstance ----------------
UXCharacterFaceCustomAnimInstance::UXCharacterFaceCustomAnimInstance()
{
}

void UXCharacterFaceCustomAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();

	if (!IsValid(GetSkelMeshComponent()))
		return;

	TArray<FName> BoneNames;
	GetSkelMeshComponent()->GetBoneNames(BoneNames);
	PreloadBoneNames(BoneNames);
}

void UXCharacterFaceCustomAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);
}

void UXCharacterFaceCustomAnimInstance::NativeUninitializeAnimation()
{
	Super::NativeUninitializeAnimation();
}

void UXCharacterFaceCustomAnimInstance::PreloadBoneNames(const TArray<FName>& InBoneNames)
{
	for (const FName& BoneName : InBoneNames)
	{
		BoneOffsetMap.FindOrAdd(BoneName);
	}
}

void UXCharacterFaceCustomAnimInstance::SetBoneOffset(const FName& BoneName, const FString& Property, const FString& Axis, float Value)
{
	FXBoneOffsetData& Offset = BoneOffsetMap.FindOrAdd(BoneName);

	if (Property.Equals(TEXT("Location"), ESearchCase::IgnoreCase))
	{
		if (Axis.Equals(TEXT("X"), ESearchCase::IgnoreCase))
			Offset.Location.X = Value;
		else if (Axis.Equals(TEXT("Y"), ESearchCase::IgnoreCase))
			Offset.Location.Y = Value;
		else if (Axis.Equals(TEXT("Z"), ESearchCase::IgnoreCase))
			Offset.Location.Z = Value;
	}
	else if (Property.Equals(TEXT("Rotation"), ESearchCase::IgnoreCase))
	{
		if (Axis.Equals(TEXT("X"), ESearchCase::IgnoreCase))
			Offset.Rotation.Roll = Value;
		else if (Axis.Equals(TEXT("Y"), ESearchCase::IgnoreCase))
			Offset.Rotation.Pitch = Value;
		else if (Axis.Equals(TEXT("Z"), ESearchCase::IgnoreCase))
			Offset.Rotation.Yaw = Value;
	}
	else if (Property.Equals(TEXT("Scale"), ESearchCase::IgnoreCase))
	{
		if (Axis.Equals(TEXT("X"), ESearchCase::IgnoreCase))
			Offset.Scale.X = Value;
		else if (Axis.Equals(TEXT("Y"), ESearchCase::IgnoreCase))
			Offset.Scale.Y = Value;
		else if (Axis.Equals(TEXT("Z"), ESearchCase::IgnoreCase))
			Offset.Scale.Z = Value;
	}

	//	UE_LOG(LogTemp, Log, TEXT("UXCharacterFaceCustomAnimInstance::SetBoneOffset::BoneName: %s || Property:: %s || Axis:: %s || Value:: %f"), *(BoneName.ToString()), *Property, *Axis, Value);
}

FXBoneOffsetData UXCharacterFaceCustomAnimInstance::GetBoneOffset(const FName& BoneName)
{
	if (const FXBoneOffsetData* Found = BoneOffsetMap.Find(BoneName))
	{
		return *Found;
	}
	return FXBoneOffsetData();
}