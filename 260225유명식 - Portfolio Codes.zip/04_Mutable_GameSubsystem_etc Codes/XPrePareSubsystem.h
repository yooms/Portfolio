#pragma once

#include "CoreMinimal.h"
#include "Async/Future.h"
#include "XBaseSubsystem.h"
#include "XPrePareSubsystem.generated.h"

class UCustomizableObjectInstance;
class UCustomizableObject;
class UXMutableInstanceAdapter;
class UPoseSearchDatabase;

UCLASS()
class SOUL_API UXPrePareSubsystem : public UXBaseSubsystem
{
    GENERATED_BODY()

public:
	UXPrePareSubsystem();

public:
	virtual void StartSubSystme() override;

protected:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	virtual void WarmUpResourcesSequential() override;

public:
	UCustomizableObjectInstance* CreateInstanceForActor(AActor* Owner, const FString& LookupKey);
	UXMutableInstanceAdapter* GetOrCreateAdapter(UCustomizableObjectInstance* Instance, AActor* Owner);

private:
	void WarmUpMaterials(TFunction<void()> OnComplete);
	void WarmUpNiagaraSystem(TFunction<void()> OnComplete);
	void WarmUpTextures();
	void WarmUpSounds(TFunction<void()> OnComplete);
	void FlushAndSaveResourceCache();
	void ShowCachingDialog();

	void StartWarmUpTexturesBatch();
	void WarmUpBatchTexture(TFunction<void()> OnComplete);
	void WarmUpPosesearchDatabase(TFunction<void()> OnComplete);
	void WaitForPoseSearchDatabasesAsync(TFunction<void()> OnReady, float PollIntervalSec = 0.05f, float TimeoutSec = 10.f);

private:
	UPROPERTY()
	TMap<FString, FPSOsCacheEntry> CachedPSOs;

	TFuture<TMap<FString, FPSOsCacheEntry>> LoadCacheFuture;

	TArray<FString> PendingTexturePaths;
	FTimerHandle WarmUpTimerHandle;
	int32 CurrentTextureIndex = 0;
	TFunction<void()> OnTextureBatchComplete;

	UPROPERTY(Transient)
	TWeakObjectPtr<UCustomizableObjectInstance> PrototypeInstance;

	UPROPERTY()
	TArray<UPoseSearchDatabase*> PoseSearchDatabases;

	UPROPERTY(Transient)
	TMap<FString, TSoftObjectPtr<UCustomizableObject>> MutableLookup;

	UPROPERTY()
	TMap<TObjectPtr<UCustomizableObjectInstance>, TObjectPtr<UXMutableInstanceAdapter>> AdapterCache;

	UPROPERTY()
	TMap<TObjectPtr<AActor>, TObjectPtr<UCustomizableObjectInstance>> MutableInstanceOwnerMaps;

#if WITH_EDITOR
	TSharedPtr<SWindow> CachingWindow;
#endif
};