// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Modules/ModuleInterface.h"
#include "XSoulModule.h"

class FSoulEditorModule : public IModuleInterface
{
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
	
	static FSoulEditorModule & Get()
	{
		return FModuleManager::LoadModuleChecked<FSoulEditorModule>("SoulEditor");
	}

private:
	void RegisterMenus();
	void OnClickFixupRedirectors();

private:
	TArray<TSharedRef<ISoulModule>> m_Module;
};