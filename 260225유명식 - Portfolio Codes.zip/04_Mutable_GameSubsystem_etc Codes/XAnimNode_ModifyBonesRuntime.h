#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNodeBase.h"
#include "XAnimNode_ModifyBonesRuntime.generated.h"

USTRUCT(BlueprintType)
struct FXBoneOffsetData
{
	GENERATED_BODY()

	FVector Location = FVector::ZeroVector;
	FRotator Rotation = FRotator::ZeroRotator;
	FVector Scale = FVector::OneVector;

	FTransform ToTransform() const
	{
		return FTransform(Rotation.Quaternion(), Location, Scale);
	}
};


// ---------------- FAnimNode_ModifyBonesRuntime ----------------
USTRUCT(BlueprintInternalUseOnly)
struct XSOULGAME_API FXAnimNode_ModifyBonesRuntime : public FAnimNode_Base
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Links)
	FComponentSpacePoseLink ComponentPose;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (PinShownByDefault))
	TMap<FName, FXBoneOffsetData> BoneOffsets;

private:
	TMap<FName, FBoneReference> BoneReferences;

	virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
	virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
	virtual void EvaluateComponentSpace_AnyThread(FComponentSpacePoseContext& Output) override;
	void InitializeBoneReferences(const FBoneContainer& RequiredBones)
	{
		for (auto& Elem : BoneReferences)
		{
			Elem.Value.Initialize(RequiredBones);
		}
	}

public:
	void SetBoneOffsets(const TMap<FName, FXBoneOffsetData>& NewOffsets)
	{
		BoneOffsets = NewOffsets;
		BoneReferences.Reset();
		for (const auto& Elem : BoneOffsets)
		{
			FBoneReference Ref;
			Ref.BoneName = Elem.Key;
			BoneReferences.Add(Elem.Key, Ref);
		}
	}
};