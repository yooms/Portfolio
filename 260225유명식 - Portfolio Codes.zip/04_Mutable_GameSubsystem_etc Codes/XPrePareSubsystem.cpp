#include "XPrePareSubsystem.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Async/Async.h"
#include "ShaderPipelineCache.h"
#include "Materials/MaterialInterface.h"
#include "NiagaraSystem.h"
#include "ShaderCodeLibrary.h"
#include "Sound/SoundCue.h"
#include "Sound/SoundWave.h"
#include "Engine/Texture.h"
#include "Engine/StreamableManager.h"
#include "ShaderCompiler.h"
#include "RenderingThread.h"
#include "NiagaraComponent.h"
#include "Sound/SampleBufferIO.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "MuCO/CustomizableObjectInstance.h"
#include "MuCO/CustomizableObject.h"
#include "XMutableInstanceAdapter.h"

#if WITH_EDITOR
#include "Engine.h"
#include "UnrealEd.h"
#include "Widgets/SWindow.h"
#include "Framework/Application/SlateApplication.h"
#include "PoseSearch/PoseSearchDerivedData.h"
#include "DerivedDataCacheKey.h"
#endif


UXPrePareSubsystem::UXPrePareSubsystem()
{
}

void UXPrePareSubsystem::StartSubSystme()
{
	WarmUpResourcesSequential();
}

void UXPrePareSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	LoadCacheFuture = Async(EAsyncExecution::ThreadPool, [this]()
		{
			return LoadResourceCache();
		});
}

void UXPrePareSubsystem::Deinitialize()
{
	Super::Deinitialize();

	FlushAndSaveResourceCache();

	MutableInstanceOwnerMaps.Empty();
}

void UXPrePareSubsystem::WarmUpResourcesSequential()
{
/*
모양이 웃기고 이런 모양으로 실제 구현하진 않으리라 생각되지만 최악의 경우 아래와 같은 형태의 처리도 가능하긴 하다.
*/
	auto StartWarmupChain = [this]()
		{
			WarmUpPosesearchDatabase([this]()
				{
					UE_LOG(LogTemp, Log, TEXT("Complete WarmUpPosesearchDatabase!"));
					WarmUpBatchTexture([this]()
						{
							UE_LOG(LogTemp, Log, TEXT("Complete WarmUpBatchTexture!"));
							WarmUpMaterials([this]()
								{
									UE_LOG(LogTemp, Log, TEXT("Complete WarmUpMaterials!"));
									WarmUpNiagaraSystem([this]()
										{
											UE_LOG(LogTemp, Log, TEXT("Complete WarmUpNiagaraSystem!"));
											WarmUpSounds([]()
												{
													UE_LOG(LogTemp, Log, TEXT("Complete WarmUpSounds and All WarmUpResourcesSequential!"));
												});
										});
								});
						});
				});
		};

	if (LoadCacheFuture.IsValid())
	{
		LoadCacheFuture.Then([this, StartWarmupChain](TFuture<TMap<FString, FPSOsCacheEntry>> Future)
			{
				CachedPSOs = Future.Get();
				AsyncTask(ENamedThreads::GameThread, StartWarmupChain);
			});
	}
	else
	{
		StartWarmupChain();
	}
}

UCustomizableObjectInstance* UXPrePareSubsystem::CreateInstanceForActor(AActor* Owner, const FString& LookupKey)
{
	if (!IsInGameThread())
	{
		UE_LOG(LogTemp, Warning, TEXT("CreateInstanceForActor called off GameThread. Dispatching to GameThread and returning nullptr."));
		AsyncTask(ENamedThreads::GameThread, [this, Owner, LookupKey]() 
			{ 
				CreateInstanceForActor(Owner, LookupKey); 
			});
		return nullptr;
	}

	const TSoftObjectPtr<UCustomizableObject> SoftRef = MutableLookup.FindRef(LookupKey);
	if (SoftRef.IsNull())
	{
		UE_LOG(LogTemp, Warning, TEXT("UXPrePareSubsystem::CreateInstanceForActor - No mutable lookup entry for key '%s'"), *LookupKey);
		return nullptr;
	}

	UCustomizableObject* COAsset = SoftRef.Get();
	if (!IsValid(COAsset))
	{
		COAsset = SoftRef.LoadSynchronous();
		if (!IsValid(COAsset))
		{
			UE_LOG(LogTemp, Warning, TEXT("UXPrePareSubsystem::CreateInstanceForActor - Failed to load UCustomizableObject for key '%s'"), *LookupKey);
			return nullptr;
		}
	}

	bool IsExistInstance = false;
	UCustomizableObjectInstance* NewInst = nullptr;
	TObjectPtr<UCustomizableObjectInstance> ExistInstance = MutableInstanceOwnerMaps.FindRef(Owner);
	if (IsValid(ExistInstance))
	{
		NewInst = ExistInstance.Get();
		IsExistInstance = true;
	}
	else
	{
		NewInst = COAsset->CreateInstance();
	}
	
	if (!IsValid(NewInst))
	{
		UE_LOG(LogTemp, Warning, TEXT("UXPrePareSubsystem::CreateInstanceForActor - CreateInstance() returned null for key '%s'"), *LookupKey);
		return nullptr;
	}

	if (PrototypeInstance.IsValid())
	{
		NewInst->CopyParametersFromInstance(PrototypeInstance.Get());
	}

	if (!IsExistInstance)
	{
		MutableInstanceOwnerMaps.Emplace(Owner, NewInst);
	}

	return NewInst;
}

UXMutableInstanceAdapter* UXPrePareSubsystem::GetOrCreateAdapter(UCustomizableObjectInstance* Instance, AActor* Owner)
{
	if (!IsValid(Instance) || !IsValid(Owner))
	{
		return nullptr;
	}

	if (auto* Found = AdapterCache.Find(Instance))
	{
		if (IsValid(*Found))
			return *Found;
	}

	UXMutableInstanceAdapter* Adapter = NewObject<UXMutableInstanceAdapter>(Owner);
	if (IsValid(Adapter))
	{
		Adapter->Initialize(Instance);
		AdapterCache.Add(Instance, Adapter);
		return Adapter;
	}

	return nullptr;
}

void UXPrePareSubsystem::WarmUpMaterials(TFunction<void()> OnComplete)
{
	PrepareAssetByClassAsync(UMaterialInterface::StaticClass(), [this, OnComplete](const TMap<FString, FGuid>& MaterialAssets)
		{
			if (!MaterialAssets.Num())
			{
				OnComplete();
				return;
			}

			std::atomic<int32> PendingLoads(MaterialAssets.Num());
			for (const auto& Pair : MaterialAssets)
			{
				const FString& Path = Pair.Key;
				const FGuid& Guid = Pair.Value;
				if (!CachedPSOs.Contains(Path) || CachedPSOs[Path].ResourceGuid != Guid)
				{
					FSoftObjectPath SoftPath(Path);
					LoadPackageAsync(SoftPath.GetLongPackageName(),
						FLoadPackageAsyncDelegate::CreateWeakLambda(this, [this, SoftPath, Path, Guid, &PendingLoads, OnComplete](const FName& PackageName, UPackage* Package, EAsyncLoadingResult::Type Result)
							{
								UObject* LoadedObject = SoftPath.ResolveObject();
								if (!LoadedObject)
								{
									LoadedObject = SoftPath.TryLoad();
								}

								if (UMaterialInterface* Material = Cast<UMaterialInterface>(LoadedObject))
								{
									Material->CacheShaders(EMaterialShaderPrecompileMode::Background);
								}
								CachedPSOs.Add(Path, FPSOsCacheEntry(Path, Guid));

								if (--(PendingLoads) == 0)
								{
									AsyncTask(ENamedThreads::GameThread, OnComplete);
								}
							})
					);
				}
				else
				{
					if (--(PendingLoads) == 0)
					{
						AsyncTask(ENamedThreads::GameThread, OnComplete);
					}
				}
			}
		});
}

void UXPrePareSubsystem::WarmUpNiagaraSystem(TFunction<void()> OnComplete)
{
	PrepareAssetByClassAsync(UNiagaraSystem::StaticClass(), [this, OnComplete](const TMap<FString, FGuid>& NiagaraAssets)
		{
			if (!NiagaraAssets.Num())
			{
				OnComplete();
				return;
			}

			std::atomic<int32> PendingLoads(NiagaraAssets.Num());
			for (const auto& Pair : NiagaraAssets)
			{
				const FString& Path = Pair.Key;
				const FGuid& Guid = Pair.Value;
				if (!CachedPSOs.Contains(Path) || CachedPSOs[Path].ResourceGuid != Guid)
				{
					FSoftObjectPath SoftPath(Path);
					LoadPackageAsync(SoftPath.GetLongPackageName(),
						FLoadPackageAsyncDelegate::CreateWeakLambda(this, [this, SoftPath, Path, Guid, &PendingLoads, OnComplete](const FName& PackageName, UPackage* Package, EAsyncLoadingResult::Type Result)
							{
								UObject* LoadedObject = SoftPath.ResolveObject();
								if (!LoadedObject)
								{
									LoadedObject = SoftPath.TryLoad();
								}

								if (UNiagaraSystem* Niagara = Cast<UNiagaraSystem>(LoadedObject))
								{
									auto* Comp = NewObject<UNiagaraComponent>(GetWorld());
									if (Comp)
									{
										Comp->SetAsset(Niagara);
										Comp->RegisterComponentWithWorld(GetWorld());
										Comp->Activate(true);
										Comp->DeactivateImmediate();
										Comp->UnregisterComponent();
									}
								}
								CachedPSOs.Add(Path, FPSOsCacheEntry(Path, Guid));

								if (--PendingLoads == 0)
								{
									AsyncTask(ENamedThreads::GameThread, OnComplete);
								}
							})
					);
				}
				else
				{
					if (--PendingLoads == 0)
					{
						AsyncTask(ENamedThreads::GameThread, OnComplete);
					}
				}
			}
		});
}

void UXPrePareSubsystem::WarmUpTextures()
{
	PrepareAssetByClassAsync(UTexture::StaticClass(), [this](const TMap<FString, FGuid>& TextureAssets)
		{
			for (const auto& Pair : TextureAssets)
			{
				const FString& Path = Pair.Key;
				const FGuid& Guid = Pair.Value;
				if (!CachedPSOs.Contains(Path) || CachedPSOs[Path].ResourceGuid != Guid)
				{
					FSoftObjectPath SoftPath(Path);
					LoadPackageAsync(SoftPath.GetLongPackageName(),
						FLoadPackageAsyncDelegate::CreateWeakLambda(this, [this, SoftPath, Path, Guid](const FName& PackageName, UPackage* Package, EAsyncLoadingResult::Type Result)
							{
								UObject* LoadedObject = SoftPath.ResolveObject();
								if (!LoadedObject)
								{
									LoadedObject = SoftPath.TryLoad();
								}

								if (UTexture* Tex = Cast<UTexture>(LoadedObject))
								{
									Tex->SetForceMipLevelsToBeResident(0.1f);
									Tex->WaitForStreaming();
								}
								CachedPSOs.Add(Path, FPSOsCacheEntry(Path, Guid));
							})
					);
				}
			}
		});
}


void UXPrePareSubsystem::WarmUpSounds(TFunction<void()> OnComplete)
{
	PrepareAssetByClassAsync(USoundWave::StaticClass(), [this, OnComplete](const TMap<FString, FGuid>& SoundWaveAssets)
		{
			if (!SoundWaveAssets.Num())
			{
				OnComplete();
				return;
			}

			std::atomic<int32> PendingLoads(SoundWaveAssets.Num());
			for (const auto& Pair : SoundWaveAssets)
			{
				const FString& Path = Pair.Key;
				const FGuid& Guid = Pair.Value;
				if (!CachedPSOs.Contains(Path) || CachedPSOs[Path].ResourceGuid != Guid)
				{
					FSoftObjectPath SoftPath(Path);
					LoadPackageAsync(SoftPath.GetLongPackageName(),
						FLoadPackageAsyncDelegate::CreateWeakLambda(this, [this, SoftPath, Path, Guid, &PendingLoads, OnComplete](const FName& PackageName, UPackage* Package, EAsyncLoadingResult::Type Result)
							{
								UObject* LoadedObject = SoftPath.ResolveObject();
								if (!LoadedObject)
								{
									LoadedObject = SoftPath.TryLoad();
								}

								if (USoundWave* Sound = Cast<USoundWave>(LoadedObject))
								{
									Sound->InitAudioResource(TEXT(""));
								}
								CachedPSOs.Add(Path, FPSOsCacheEntry(Path, Guid));

								if (--(PendingLoads) == 0)
								{
									AsyncTask(ENamedThreads::GameThread, OnComplete);
								}
							}
						)
					);
				}
				else
				{
					if (--(PendingLoads) == 0)
					{
						AsyncTask(ENamedThreads::GameThread, OnComplete);
					}
				}
			}
		});
}

void UXPrePareSubsystem::FlushAndSaveResourceCache()
{
	Async(EAsyncExecution::ThreadPool, [this]()
		{
			if (!CachedPSOs.Num())
				return;

			SaveResourceCache(CachedPSOs);
#if WITH_EDITOR
			UE_LOG(LogTemp, Warning, TEXT(" >>>>>>>>>>>>> CachedPSOsCount: %d"), CachedPSOs.Num());
#endif
		});
}

void UXPrePareSubsystem::ShowCachingDialog()
{
#if WITH_EDITOR
	if (GIsEditor && GetWorld() && EWorldType::PIE == GetWorld()->WorldType)
	{
		CachingWindow = SNew(SWindow)
			.Title(FText::FromString(TEXT("리소스 캐싱 중...")))
			.ClientSize(FVector2D(400, 100))
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			.IsTopmostWindow(true)
			.SizingRule(ESizingRule::FixedSize)
			[
				SNew(STextBlock)
					.Text(FText::FromString(TEXT("\n리소스를 캐싱 중입니다. 잠시만 기다려 주세요...\n최초 캐싱을 실행 할 경우 시간이 조금 걸릴 수 있습니다.\n")))
					.Justification(ETextJustify::Center)
			];

		FSlateApplication::Get().AddWindow(CachingWindow.ToSharedRef());

		FTimerHandle TimerHandle;
		if (GetWorld())
		{
			GetWorld()->GetTimerManager().SetTimer(TimerHandle, [this]()
				{
					if (CachingWindow.IsValid())
					{
						CachingWindow->RequestDestroyWindow();
						CachingWindow = nullptr;
					}
				}, 3.0f, false);
		}
	}
#endif
}

void UXPrePareSubsystem::StartWarmUpTexturesBatch()
{
	if (PendingTexturePaths.IsEmpty())
		return;

	const int32 BatchSize = 5;
	const int32 MaxIndex = PendingTexturePaths.Num();
	for (int32 i = CurrentTextureIndex; i < MaxIndex; ++i)
	{
		const FString& Path = PendingTexturePaths[i];
		FGuid Guid = CachedPSOs.Contains(Path) ? CachedPSOs[Path].ResourceGuid : FGuid();
		if (!CachedPSOs.Contains(Path) || CachedPSOs[Path].ResourceGuid != Guid)
		{
			FSoftObjectPath SoftPath(Path);
			LoadPackageAsync(SoftPath.GetLongPackageName(),
				FLoadPackageAsyncDelegate::CreateWeakLambda(this, [this, SoftPath, Path, Guid](const FName& PackageName, UPackage* Package, EAsyncLoadingResult::Type Result)
					{
						UObject* LoadedObject = SoftPath.ResolveObject();
						if (!LoadedObject) LoadedObject = SoftPath.TryLoad();

						if (UTexture* Tex = Cast<UTexture>(LoadedObject))
						{
							Tex->SetForceMipLevelsToBeResident(1.0f);
							Tex->WaitForStreaming();
						}
						CachedPSOs.Add(Path, FPSOsCacheEntry(Path, Guid));
					})
			);
		}
	}

	CurrentTextureIndex = MaxIndex;
	if (CurrentTextureIndex >= PendingTexturePaths.Num())
	{
		GetWorld()->GetTimerManager().ClearTimer(WarmUpTimerHandle);
	}
}

void UXPrePareSubsystem::WarmUpBatchTexture(TFunction<void()> OnComplete)
{
	PrepareAssetByClassAsync(UTexture::StaticClass(), [this, OnComplete](const TMap<FString, FGuid>& TextureAssets)
		{
			OnTextureBatchComplete = OnComplete;
			if (!TextureAssets.Num())
			{
				OnTextureBatchComplete();
				return;
			}

			PendingTexturePaths.Reset();
			for (const auto& Pair : TextureAssets)
			{
				PendingTexturePaths.Add(Pair.Key);
			}
			CurrentTextureIndex = 0;

			TWeakObjectPtr<UXPrePareSubsystem> WeakThis(this);
			GetWorld()->GetTimerManager().SetTimer(WarmUpTimerHandle, FTimerDelegate::CreateLambda([WeakThis]()
					{
						if (!WeakThis.IsValid())
						{
							return;
						}

						auto* Self = WeakThis.Get();
						Self->StartWarmUpTexturesBatch();

						if (Self->CurrentTextureIndex >= Self->PendingTexturePaths.Num())
						{
							Self->GetWorld()->GetTimerManager().ClearTimer(Self->WarmUpTimerHandle);
							Self->PendingTexturePaths.Empty();
							Self->CurrentTextureIndex = 0;

							Self->OnTextureBatchComplete();
						}
					}),
				0.25f, true);
		});
}

void UXPrePareSubsystem::WarmUpPosesearchDatabase(TFunction<void()> OnComplete)
{
	PrepareAssetByClassAsync(UPoseSearchDatabase::StaticClass(), [this, OnComplete](const TMap<FString, FGuid>& PoseSearchDBAssets)
		{
			if (!PoseSearchDBAssets.Num())
			{
				AsyncTask(ENamedThreads::GameThread, OnComplete);
				return;
			}
			UE_LOG(LogTemp, Log, TEXT("PoseSearchDatabase Asset Load Complete: %d Count"), PoseSearchDBAssets.Num());

			PoseSearchDatabases.Reset();

			auto PendingLoads = MakeShared<std::atomic<int32>, ESPMode::ThreadSafe>(PoseSearchDBAssets.Num());
			for (const auto& Pair : PoseSearchDBAssets)
			{
				const FString& Path = Pair.Key;
				const FGuid& Guid = Pair.Value;
				const bool bCachedSame = CachedPSOs.Contains(Path) && (CachedPSOs[Path].ResourceGuid == Guid);
				if (bCachedSame)
				{
					if (--(*PendingLoads) == 0)
					{
						WaitForPoseSearchDatabasesAsync([this, OnComplete]()
							{
								AsyncTask(ENamedThreads::GameThread, OnComplete);
							});
					}
					continue;
				}

				const FSoftObjectPath SoftPath(Path);
				const FString LongPkg = SoftPath.GetLongPackageName();
				LoadPackageAsync(LongPkg, FLoadPackageAsyncDelegate::CreateWeakLambda(this, [this, SoftPath, Path, Guid, PendingLoads, OnComplete](const FName& /*PkgName*/, UPackage* /*Pkg*/, EAsyncLoadingResult::Type /*Result*/)
						{
							UObject* LoadedObject = SoftPath.ResolveObject();
							if (!IsValid(LoadedObject))
							{
								LoadedObject = SoftPath.TryLoad();
							}

							if (UPoseSearchDatabase* PSD = Cast<UPoseSearchDatabase>(LoadedObject))
							{
#if WITH_EDITOR
								const auto Req = UE::PoseSearch::FAsyncPoseSearchDatabasesManagement::RequestAsyncBuildIndex(PSD, UE::PoseSearch::ERequestAsyncBuildFlag::ContinueRequest);
								UE_LOG(LogTemp, Log, TEXT("[PoseSearch] Request index: %s → %d (0:InProgress,1:Success,2:Failed)"), *PSD->GetName(), (int32)Req);
#endif
								PoseSearchDatabases.Add(PSD);
							}
							else
							{
								UE_LOG(LogTemp, Warning, TEXT("[PoseSearch] Not a UPoseSearchDatabase: %s"), *Path);
							}
							CachedPSOs.Add(Path, FPSOsCacheEntry(Path, Guid));

							if (--(*PendingLoads) == 0)
							{
								WaitForPoseSearchDatabasesAsync([this, OnComplete]()
									{
										AsyncTask(ENamedThreads::GameThread, OnComplete);
									});
							}
						}));
			}
		});
}

static bool IsPoseSearchReady(const UPoseSearchDatabase* PSD)
{
	if (!IsValid(PSD) || !PSD->Schema)
	{
		return false;
	}

	const auto& Index = PSD->GetSearchIndex();
	return Index.GetNumPoses() > 0;
}

void UXPrePareSubsystem::WaitForPoseSearchDatabasesAsync(TFunction<void()> OnReady, float PollIntervalSec /*=0.05f*/, float TimeoutSec /*=10.f*/)
{
	if (PoseSearchDatabases.Num() == 0)
	{
		AsyncTask(ENamedThreads::GameThread, [OnReady]()
			{
				if (OnReady)
					OnReady(); 
			});
		return;
	}

	struct FWaitState
	{
		double StartTime = 0.0;
		FTimerHandle Timer;
	};

	TSharedRef<TFunction<void()>> Tick = MakeShared<TFunction<void()>>();
	TSharedRef<FWaitState, ESPMode::ThreadSafe> State = MakeShared<FWaitState, ESPMode::ThreadSafe>();
	State->StartTime = FPlatformTime::Seconds();

	*Tick = [this, OnReady, PollIntervalSec, TimeoutSec, State, Tick]()
		{
			bool bAllReady = true;
			for (UPoseSearchDatabase* PSD : PoseSearchDatabases)
			{
				if (!IsPoseSearchReady(PSD))
				{
#if WITH_EDITOR
					if (IsValid(PSD))
					{
						UE::PoseSearch::FAsyncPoseSearchDatabasesManagement::RequestAsyncBuildIndex(PSD, UE::PoseSearch::ERequestAsyncBuildFlag::ContinueRequest);
					}
#endif
					bAllReady = false;
				}
			}

			if (bAllReady)
			{
				GetWorld()->GetTimerManager().ClearTimer(State->Timer);
				if (OnReady)
				{
					OnReady();
				}
				return;
			}

			const double Elapsed = FPlatformTime::Seconds() - State->StartTime;
			if (Elapsed >= TimeoutSec)
			{
				UE_LOG(LogTemp, Warning, TEXT("[PoseSearch] Wait timed out after %.2fs. Continuing anyway."), Elapsed);
				GetWorld()->GetTimerManager().ClearTimer(State->Timer);
				if (OnReady)
				{
					OnReady();
				}
				return;
			}

			GetWorld()->GetTimerManager().SetTimer(State->Timer, FTimerDelegate::CreateLambda(*Tick), PollIntervalSec, false);
		};

	(*Tick)();
}
