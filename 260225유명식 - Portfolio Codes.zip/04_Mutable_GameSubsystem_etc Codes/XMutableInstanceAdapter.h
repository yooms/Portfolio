#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "MuCO/CustomizableObjectInstance.h"
#include "XMutableInstanceAdapter.generated.h"


DECLARE_MULTICAST_DELEGATE_OneParam(FOnMutableInstanceUpdated, UCustomizableObjectInstance* /*Instance*/);

UCLASS()
class UXMutableInstanceAdapter : public UObject
{
    GENERATED_BODY()

public:
	FOnMutableInstanceUpdated OnUpdated;

private:
	TWeakObjectPtr<UCustomizableObjectInstance> Instance;

private:
    UFUNCTION()
	void HandleInstanceUpdated(UCustomizableObjectInstance* UpdatedInstance)
	{
		if (!IsInGameThread())
		{
			AsyncTask(ENamedThreads::GameThread, [this, UpdatedInstance]()
				{
					HandleInstanceUpdated(UpdatedInstance);
				});
			return;
		}
		OnUpdated.Broadcast(UpdatedInstance);
	}

public:
    void Initialize(UCustomizableObjectInstance* InInstance)
    {
        if (!IsValid(InInstance))
			return;

        Instance = InInstance;
        Instance->UpdatedNativeDelegate.AddUObject(this, &UXMutableInstanceAdapter::HandleInstanceUpdated);
    }

    virtual void BeginDestroy() override
    {
        if (Instance.IsValid())
        {
            Instance->UpdatedNativeDelegate.RemoveAll(this);
        }
        Super::BeginDestroy();
    }
};