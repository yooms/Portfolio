#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "Dom/JsonObject.h"
#include "XBaseSubsystem.generated.h"


USTRUCT()
struct FPSOsCacheEntry
{
	GENERATED_BODY()

	FString ResourcePath;
	FGuid ResourceGuid;

	FPSOsCacheEntry() {}
	FPSOsCacheEntry(const FString& InPath, const FGuid& InGuid)
		: ResourcePath(InPath), ResourceGuid(InGuid)
	{
	}

	TSharedPtr<FJsonObject> ToJson() const
	{
		TSharedPtr<FJsonObject> Json = MakeShared<FJsonObject>();
		Json->SetStringField(TEXT("Path"), ResourcePath);
		Json->SetStringField(TEXT("GUID"), ResourceGuid.ToString());
		return Json;
	}

	static FPSOsCacheEntry FromJson(const TSharedPtr<FJsonObject>& Json)
	{
		FPSOsCacheEntry Entry;
		Entry.ResourcePath = Json->GetStringField(TEXT("Path"));
		FString GuidStr = Json->GetStringField(TEXT("GUID"));
		FGuid::Parse(GuidStr, Entry.ResourceGuid);
		return Entry;
	}
};


UCLASS()
class SOUL_API UXBaseSubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
	UXBaseSubsystem();

public:
	virtual void StartSubSystme() {}

protected:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	virtual void PrepareAssetByClassAsync(const UClass* AssetClass, TFunction<void(const TMap<FString, FGuid>&)> OnComplete);
	virtual void WarmUpResourcesSequential() {}

	void SaveResourceCache(const TMap<FString, FPSOsCacheEntry>& EntriesMap);
	TMap<FString, FPSOsCacheEntry> LoadResourceCache();
	FGuid GetAssetStableGuid(UObject* Asset);

	const FString EncryptString(const FString& InString, const FString& KeyString);
	const FString DecryptString(const FString& EncryptedBase64, const FString& KeyString);

};