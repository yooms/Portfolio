#include "XAssetFixupRedirectorUtility.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "ObjectTools.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "UObject/ObjectRedirector.h"
#include "AssetRegistry/ARFilter.h"

void UXAssetFixupRedirectorUtility::FixupRedirectorsWithExclusion()
{
    IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry").Get();

    FARFilter Filter;
    Filter.PackagePaths.Add(FName("/Game"));
	Filter.ClassPaths.Add(FTopLevelAssetPath(TEXT("/Script/CoreUObject.ObjectRedirector")));
    Filter.bRecursivePaths = true;

    TArray<FName> ExcludePaths = {
        FName("/Game/Developers")
    };

    TArray<FAssetData> Redirectors;
    AssetRegistry.GetAssets(Filter, Redirectors);

    TArray<UObjectRedirector*> ValidRedirectors;
    FString LogText;

    for (const FAssetData& Asset : Redirectors)
    {
        bool bExcluded = false;
        for (const FName& ExcludePath : ExcludePaths)
        {
            if (Asset.PackagePath.ToString().StartsWith(ExcludePath.ToString()))
            {
                bExcluded = true;
                LogText += FString::Printf(TEXT("[Excluded] %s\n"), *Asset.GetObjectPathString());
                break;
            }
        }

        if (!bExcluded)
        {
            if (UObjectRedirector* Redirector = Cast<UObjectRedirector>(Asset.GetAsset()))
            {
                ValidRedirectors.Add(Redirector);
                LogText += FString::Printf(TEXT("[Fixed] %s\n"), *Asset.GetObjectPathString());
            }
        }
    }

    if (ValidRedirectors.Num() > 0)
    {
        FAssetToolsModule& AssetToolsModule = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools");
        AssetToolsModule.Get().FixupReferencers(ValidRedirectors);
    }

    const FString LogPathString = FPaths::ProjectSavedDir() / TEXT("Logs/RedirectFixupLog.txt");
    FFileHelper::SaveStringToFile(LogText, *LogPathString);

    UE_LOG(LogTemp, Log, TEXT("Redirector fixup complete. See log: %s"), *LogPathString);
}