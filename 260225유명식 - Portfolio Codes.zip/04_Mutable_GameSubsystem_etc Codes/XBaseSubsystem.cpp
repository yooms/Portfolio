#include "XBaseSubsystem.h"
#include "Misc/AES.h"
#include "Misc/Base64.h"
#include "ShaderPipelineCache.h"
#include "Async/Async.h"
#include "Containers/StringConv.h"
#include "Async/TaskGraphInterfaces.h"
#include "Async/TaskGraphFwd.h"
#include "HAL/FileManager.h"
#include "Serialization/Archive.h"
#include "Misc/App.h"
#include "ShaderCodeLibrary.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Engine/AssetManager.h"


UXBaseSubsystem::UXBaseSubsystem()
{
}

void UXBaseSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

}

void UXBaseSubsystem::Deinitialize()
{
	Super::Deinitialize();
}

void UXBaseSubsystem::PrepareAssetByClassAsync(const UClass* AssetClass, TFunction<void(const TMap<FString, FGuid>&)> OnComplete)
{
	AsyncTask(ENamedThreads::GameThread, [=, this]()
		{
			FARFilter Filter;
			Filter.ClassPaths.Add(AssetClass->GetClassPathName());
			Filter.PackagePaths.Add("/Game");
			Filter.bRecursivePaths = true;
			Filter.bRecursiveClasses = true;

			TArray<FAssetData> AssetList;
			FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
			AssetRegistryModule.Get().GetAssets(Filter, AssetList);

			TArray<FString> ExcludedFolders = {
				TEXT("/Game/Work")
#if WITH_EDITOR
				,TEXT("/Game/__ExternalActors__")
				,TEXT("/Game/__ExternalObjects__")
				,TEXT("/Game/_GENERATED")
				,TEXT("/Game/Developers")
				,TEXT("/Game/Editor")
				,TEXT("/Game/ExampleContent")
				,TEXT("/Game/Fonts")
				,TEXT("/Game/UI")
				,TEXT("/Game/FX/FX_Test")
#endif
			};

			TMap<FString, FGuid> LoadedAssets;
			for (const FAssetData& Asset : AssetList)
			{
				bool bExcluded = false;
				for (const FString& ExcludedPath : ExcludedFolders)
				{
					if (Asset.PackagePath.ToString().StartsWith(ExcludedPath))
					{
						bExcluded = true;
						break;
					}
				}

				if (bExcluded) continue;

				if (UObject* Loaded = Asset.GetAsset())
				{
					const FString Path = Asset.GetObjectPathString();
					const FGuid Guid = GetAssetStableGuid(Loaded);
					LoadedAssets.Add(Path, Guid);
				}
			}
			OnComplete(LoadedAssets);
		});
}

void UXBaseSubsystem::SaveResourceCache(const TMap<FString, FPSOsCacheEntry>& EntriesMap)
{
	TArray<TSharedPtr<FJsonValue>> JsonArray;
	for (const auto& Pair : EntriesMap)
	{
		JsonArray.Add(MakeShared<FJsonValueObject>(Pair.Value.ToJson()));
	}

	FString JsonString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);
	FJsonSerializer::Serialize(JsonArray, Writer);

	FString ResultString;
#if UE_BUILD_SHIPPING
	const FString Encrypted = EncryptString(JsonString, TEXT("|2bP#f1)HbHcm2U"));
	ResultString = MoveTemp(Encrypted);
#else
	ResultString = MoveTemp(JsonString);
#endif

	const FString kSavedCachePath = FPaths::ProjectSavedDir() / TEXT("Cache/ResourceCaches.cache");
	IFileManager::Get().MakeDirectory(*(FPaths::ProjectSavedDir() / TEXT("Cache")), true);

	FTCHARToUTF8 Convert(*ResultString);
	FFileHelper::SaveArrayToFile(TArray<uint8>((const uint8*)Convert.Get(), Convert.Length()), *kSavedCachePath);
}

TMap<FString, FPSOsCacheEntry> UXBaseSubsystem::LoadResourceCache()
{
	const FString kSavedCachePath = FPaths::ProjectSavedDir() / TEXT("Cache/ResourceCaches.cache");
	const FString kInitialCachePath = FPaths::ProjectContentDir() / TEXT("Developers") / TEXT("ResourceCaches.cache");

	if (!FPaths::FileExists(kSavedCachePath) && FPaths::FileExists(kInitialCachePath))
	{
		IFileManager::Get().MakeDirectory(*(FPaths::ProjectSavedDir() / TEXT("Cache")), true);
		FPlatformFileManager::Get().GetPlatformFile().CopyFile(*kSavedCachePath, *kInitialCachePath);
	}

	FString JsonEncrypted;
	if (!FFileHelper::LoadFileToString(JsonEncrypted, *kSavedCachePath))
	{
		return {};
	}

	FString ResultString;
#if UE_BUILD_SHIPPING
	FString JsonDecrypted = DecryptString(JsonEncrypted, TEXT("|2bP#f1)HbHcm2U"));
	ResultString = MoveTemp(JsonDecrypted);
#else
	ResultString = MoveTemp(JsonEncrypted);
#endif

	TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResultString);
	TArray<TSharedPtr<FJsonValue>> JsonArray;
	TMap<FString, FPSOsCacheEntry> Result;

	if (FJsonSerializer::Deserialize(Reader, JsonArray))
	{
		for (auto& Value : JsonArray)
		{
			TSharedPtr<FJsonObject> Obj = Value->AsObject();
			if (Obj.IsValid())
			{
				auto Entry = FPSOsCacheEntry::FromJson(Obj);
				Result.Add(Entry.ResourcePath, Entry);
			}
		}
	}
	return Result;
}

FGuid UXBaseSubsystem::GetAssetStableGuid(UObject* Asset)
{
	if (!IsValid(Asset))
		return FGuid();
#if WITH_EDITOR
	const UPackage* Package = Asset->GetOutermost();
	const FString PackageName = Package->GetName();
	const FGuid PackageGuid = Package->GetGuid();

	const FString Composite = PackageName + TEXT("_") + PackageGuid.ToString(EGuidFormats::DigitsWithHyphensInBraces);
	FTCHARToUTF8 Converter(*Composite);

	uint8 Hash[20];
	FSHA1::HashBuffer(Converter.Get(), Converter.Length(), Hash);

	FGuid ComputedGuid;
	FMemory::Memcpy(&ComputedGuid, Hash, sizeof(FGuid));
	return ComputedGuid;
#else
	return FGuid();
#endif
}

const FString UXBaseSubsystem::EncryptString(const FString& InString, const FString& KeyString)
{
	TArray<uint8> Data;
	Data.Append((const uint8*)TCHAR_TO_UTF8(*InString), InString.Len());

	uint8 Key[32] = { 0 };
	FTCHARToUTF8 KeyUtf8(*KeyString);
	FMemory::Memcpy(Key, KeyUtf8.Get(), FMath::Min(KeyUtf8.Length(), (int32)sizeof(Key)));

	const int32 Padding = 16 - (Data.Num() % 16);
	for (int32 i = 0; i < Padding; ++i) Data.Add(Padding);

	TArray<uint8> EncryptedData;
	EncryptedData.SetNumUninitialized(Data.Num());
	FAES::EncryptData(Data.GetData(), Data.Num(), Key, sizeof(Key));

	return FBase64::Encode(Data);
}

const FString UXBaseSubsystem::DecryptString(const FString& EncryptedBase64, const FString& KeyString)
{
	TArray<uint8> EncryptedData;
	FBase64::Decode(EncryptedBase64, EncryptedData);

	uint8 Key[32] = { 0 };
	FTCHARToUTF8 KeyUtf8(*KeyString);
	FMemory::Memcpy(Key, KeyUtf8.Get(), FMath::Min(KeyUtf8.Length(), (int32)sizeof(Key)));

	FAES::DecryptData(EncryptedData.GetData(), EncryptedData.Num(), Key, sizeof(Key));

	const int32 Padding = EncryptedData.Last();
	EncryptedData.SetNum(EncryptedData.Num() - Padding);

	const FString Result = FString(UTF8_TO_TCHAR(EncryptedData.GetData()));
	return Result;
}
