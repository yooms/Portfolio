/********************************************************************
	created:	2011/08/08
	filename: 	d:\Client\PSingleton.h
	file path:	d:\Client
	file base:	PhoenixSingleton
	file ext:	h
	author:		������ - A.K.A yooms or prod1gy
				prod1gy@nate.com
	
	purpose:	�� �״�� PhoenixSingleton ��.
*********************************************************************/

#ifndef _PSINGLETON_H_
#define _PSINGLETON_H_

#include <new>
#include "../../Scaleform/ScaleformServer.h"

template<typename T> class Create_Static_Instance
{
public:
	static T* Create()
	{
		static static_memory Inst;
		return new(&Inst) T;
	}

	static void Destroy(T* p)
	{
		p->~T();
	}

private:
	union static_memory
	{
		char tMem[sizeof(T)];
	};
};

typedef void (*atexit_pfn_t) ();

template<typename T> class Destroy_Static_Instance
{
public:
	static void KillInstance(T*, atexit_pfn_t pfn)
	{
		atexit(pfn);
	}
};

template<typename T, 
template<class> class creation = Create_Static_Instance,
template<class> class destruction = Destroy_Static_Instance
> class PSingleton
{
private:
	static T* m_pInstance;
	static bool m_bDestroy;

private:
	PSingleton() {}
	~PSingleton() {}

public:
	static void Destroy_Instance()
	{
		if(m_pInstance)
		{
			creation<T>::Destroy(m_pInstance);
			m_pInstance = NULL;
		}

		m_bDestroy = true;
	}

	static T* GetInstance()
	{
		if(!m_pInstance)
		{
			if(m_bDestroy)
			{
				m_bDestroy =false;
			}

			m_pInstance = creation<T>::Create();
			destruction<T>::KillInstance(m_pInstance, Destroy_Instance);
		}

		return m_pInstance;
	}
};

template<typename T,
template<class> class C,
template<class> class D
>
T* PSingleton<T, C, D>::m_pInstance = NULL;

template<typename T,
template<class> class C,
template<class> class D
>
bool PSingleton<T, C, D>::m_bDestroy = false;

#define _GET_PSINGLETON(__psingleton)	PSingleton<__psingleton>::GetInstance()
#define _DELETE_PSINGLETON(__psingleton)	PSingleton<__psingleton>::Destroy_Instance()


#endif //_PSINGLETON_H_