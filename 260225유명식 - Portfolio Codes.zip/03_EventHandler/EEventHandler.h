#pragma once
// Fill out your copyright notice in the Description page of Project Settings.

//#ifdef EVENT_HANDLER
#include "EEventBase.h"
#include "Util/Common/ECommonType.h"
#include "System/Engine/EGameInstance.h"
#include "EEventDispatcher.h"
#include "EEventHandler.generated.h"

/**
*
*/
UCLASS()
class EMBER_API UEEventHandler : public UObject
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UEEventHandler();

	void ManagerInit(class UEGameInstance* InGameInstance);

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	template<typename T>
	void SendEvent(T* Event, EENM_EventSide Side = EENM_EventSide::ClientToClient, uint32 Identifier = 0);

	template<typename Tparam, class T, class Tfunc>
	void RegisterEvent(T* Obj, void (T::*memFunc)(Tfunc*), uint32 Identifier = 0);

	template<typename Tparam, class T, class Tfunc>
	void RegisterEventU(T* Obj, void (T::*memFunc)(Tfunc*), uint32 Identifier = 0);
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

private:
	UPROPERTY()
	class UEEventDispatcher* EventDispatcher;

	UPROPERTY()
	class UEGameInstance* GameInstance;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template<typename T>
void UEEventHandler::SendEvent(T* Event, EENM_EventSide Side/* = VENM_EventSide::ClientToClient*/, uint32 Identifier/* = 0*/)
{
	if (!Event) return;
	if (!EventDispatcher->IsValidLowLevel()) return;

	EventDispatcher->InsertEvent<T>(Event, Side, Identifier);
}

template<typename Tparam, class T, class Tfunc>
void UEEventHandler::RegisterEvent(T* Obj, void (T::*memFunc)(Tfunc*), uint32 Identifier/* = 0*/)
{
	if (!Obj) return;
	if (!EventDispatcher->IsValidLowLevel()) return;

	FEventHandlerModify<Tparam>* Event = new FEventHandlerModify<Tparam>;
	if (Event)
	{
		FName Name = Event->GetEventClassName();
		EventContainer& EventContain = EventDispatcher->GetEventContainer();
		if (true == EventContain.Contains(Name))
		{
			EventObject* Events = EventContain.FindRef(Name);
			Event->Function.BindRaw(Obj, memFunc);
			Event->SetTargetEventIdentify(Identifier);

			FEventHandlerBase* EventBase = static_cast<FEventHandlerBase*>(Event);
			if (EventBase)
			{
				Events->Emplace(EventBase);
			}
		}
		else
		{
			EventObject* Events = new EventObject;
			Event->Function.BindRaw(Obj, memFunc);
			Event->SetTargetEventIdentify(Identifier);

			FEventHandlerBase* EventBase = static_cast<FEventHandlerBase*>(Event);
			if (EventBase)
			{
				Events->Emplace(EventBase);

				EventContain.Emplace(Name, Events);
			}
		}
	}
}

template<typename Tparam, class T, class Tfunc>
void UEEventHandler::RegisterEventU(T* Obj, void (T::*memFunc)(Tfunc*), uint32 Identifier/* = 0*/)
{
	if (!Obj) return;
	if (!EventDispatcher->IsValidLowLevel()) return;

	FEventHandlerModify<Tparam>* Event = new FEventHandlerModify<Tparam>;
	if (Event)
	{
		FName Name = Event->GetEventClassName();
		EventContainer& EventContain = EventDispatcher->GetEventContainer();
		if (true == EventContain.Contains(Name))
		{
			EventObject* Events = EventContain.FindRef(Name);
			if (Events)
			{
				UObject* pObj = static_cast<UObject*>(Obj);
				if (pObj && pObj->IsValidLowLevel())
				{
					Event->Function.BindUObject(Obj, memFunc);
					Event->SetTargetEventIdentify(Identifier);

					FEventHandlerBase* EventBase = static_cast<FEventHandlerBase*>(Event);
					if (EventBase)
					{
						Events->Emplace(EventBase);
					}
				}
			}
		}
		else
		{
			EventObject* Events = new EventObject;
			if (Events)
			{
				UObject* pObj = static_cast<UObject*>(Obj);
				if (pObj && pObj->IsValidLowLevel())
				{
					Event->Function.BindUObject(Obj, memFunc);
					Event->SetTargetEventIdentify(Identifier);

					FEventHandlerBase* EventBase = static_cast<FEventHandlerBase*>(Event);
					if (EventBase)
					{
						Events->Emplace(EventBase);

						EventContain.Emplace(Name, Events);
					}
				}
			}
		}
	}
}
//#endif //EVENT_HANDLER