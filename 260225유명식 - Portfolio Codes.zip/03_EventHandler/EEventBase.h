#pragma once

//#ifdef EVENT_HANDLER
#include <typeinfo>
#include "Util/Common/ECommonType.h"
#include "EEventBase.generated.h"


USTRUCT()
struct FEventBase
{
	GENERATED_USTRUCT_BODY()

public:
	virtual EENM_EventPriority GetPriority()
	{
		return EENM_EventPriority::None;
	}

	virtual FName GetTypeName()
	{
		return TEXT("");
	}

	virtual EENM_EventSide GetEventSide()
	{
		return EENM_EventSide::None;
	}
};

class FEventHandlerBase
{
public:
	void Execute(void* event)
	{
		return ExecuteInternal(event);
	}

	void SetTargetEventIdentify(uint32 id)
	{
		Identifier = id;
	}

	uint32 GetTargetEventIdentify()
	{
		return Identifier;
	}

	virtual void ExecuteInternal(void* event) = 0;

	uint32 Identifier = 0;
};

template<typename T>
class FEventHandler : public FEventHandlerBase
{
public:
	virtual ~FEventHandler()
	{
	}

	typedef T MsgType;
	DECLARE_MULTICAST_DELEGATE_OneParam(FEventFunc, T*);

	void ExecuteInternal(void* event)
	{
		return Function.Broadcast((MsgType*)event);
	}

	FName GetEventClassName()
	{
		return typeid(T).name();
	}

	void EventRemoveAll()
	{
		Function.RemoveAll(this);
	}

	FEventFunc Function;
};

template<typename T>
class FEventHandlerModify : public FEventHandlerBase
{
public:
	virtual ~FEventHandlerModify() {}

	typedef T MsgType;
	DECLARE_DELEGATE_OneParam(FEventFunc, T*);

	void ExecuteInternal(void* event)
	{
		Function.ExecuteIfBound((MsgType*)event);
	}

	FName GetEventClassName()
	{
		return typeid(T).name();
	}

	void EventUnbind()
	{
		Function.Unbind();
	}

	FEventFunc Function;
};

typedef TArray<FEventHandlerBase*> EventObject;
typedef TMap<FName, EventObject*> EventContainer;
typedef TArray<uint32> EventIdentifierQueue;

typedef TMap<FName, FEventHandlerBase*> EventsRegister;
typedef TArray<FEventBase*> EventsQueue;
typedef TArray<EventsQueue> EventsPool;
//#endif //EVENT_HANDLER