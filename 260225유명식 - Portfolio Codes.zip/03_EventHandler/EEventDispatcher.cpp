// Fill out your copyright notice in the Description page of Project Settings.

#include "Ember.h"

//#ifdef EVENT_HANDLER
UEEventDispatcher::UEEventDispatcher(const class FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	EventMap.Empty();
	ClientEventPriorityQueue.Empty();
	ServerEventPriorityQueue.Empty();

	ClientEventIdQueue.Empty();
	ServerEventIdQueue.Empty();
}

UEEventDispatcher::~UEEventDispatcher()
{
	EventMap.Empty();
	ClientEventPriorityQueue.Empty();
	ServerEventPriorityQueue.Empty();

	ClientEventIdQueue.Empty();
	ServerEventIdQueue.Empty();
}

void UEEventDispatcher::SetGameInstance(class UEGameInstance* InGameInstance)
{
	if (InGameInstance->IsValidLowLevel())
	{
		GameInstance = InGameInstance;
		GameInstance->GetTimerManager().SetTimerForNextTick(this, &UEEventDispatcher::FlushEvent);
	}
}

void UEEventDispatcher::QueueDispatchEvent(FName Name, FEventBase* Event, uint32 Identifier)
{
	if (!Event) return;

	EventObject* Events = EventMap.FindRef(Name);
	if (Events)
	{
		for (FEventHandlerBase* Base : *Events)
		{
			if (Base)
			{
				if (0 == Identifier)
				{
					Base->Execute((void*)Event);
				}
				else
				{
					if (Identifier == Base->GetTargetEventIdentify())
					{
						Base->Execute((void*)Event);
					}
				}
			}
		}
	}
}

void UEEventDispatcher::FlushEvent()
{
	if (GIsEditor)
	{
		if (ENetMode::NM_Client == GameInstance->GetWorld()->GetNetMode() || ENetMode::NM_Standalone == GameInstance->GetWorld()->GetNetMode())
		{
			ClientEventQueue();
		}
		else if (ENetMode::NM_DedicatedServer == GameInstance->GetWorld()->GetNetMode() || ENetMode::NM_Standalone == GameInstance->GetWorld()->GetNetMode())
		{
			ServerEventQueue();
		}
	}
	else
	{
		if (IsRunningGame())
		{
			ClientEventQueue();
		}
		else if (IsRunningDedicatedServer())
		{
			ServerEventQueue();
		}
	}
}

void UEEventDispatcher::Tick(float DeltaTime)
{

}

void UEEventDispatcher::ClientEventQueue()
{
	if (ClientEventPriorityQueue.Num() && ClientEventIdQueue.Num())
	{
		if (ClientEventPriorityQueue.Num() == ClientEventIdQueue.Num())
		{
			uint32 pos = 0;
			for (auto Event : ClientEventPriorityQueue)
			{
				if (Event)
				{
					QueueDispatchEvent((Event->GetTypeName()), Event, ClientEventIdQueue[pos]);
					++pos;
				}
			}
		}
	}

	ClientEventPriorityQueue.Empty();
	ClientEventIdQueue.Empty();
}

void UEEventDispatcher::ServerEventQueue()
{
	if (ServerEventPriorityQueue.Num() && ServerEventIdQueue.Num())
	{
		if (ServerEventPriorityQueue.Num() == ServerEventIdQueue.Num())
		{
			uint32 pos = 0;
			for (auto Event : ServerEventPriorityQueue)
			{
				if (Event)
				{
					QueueDispatchEvent((Event->GetTypeName()), Event, ServerEventIdQueue[pos]);
					++pos;
				}
			}
		}
	}

	ServerEventPriorityQueue.Empty();
	ServerEventIdQueue.Empty();
}
//#endif //EVENT_HANDLER
