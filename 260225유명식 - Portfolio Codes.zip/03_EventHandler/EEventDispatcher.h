#pragma once

//#ifdef EVENT_HANDLER
#include "EEventBase.h"
#include "System/Engine/EGameInstance.h"
#include "EEventDispatcher.generated.h"

UCLASS()
class EMBER_API UEEventDispatcher : public UObject, public FTickableGameObject
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UEEventDispatcher();

	void SetGameInstance(class UEGameInstance* InGameInstance);

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	EventContainer& GetEventContainer() { return EventMap; }

	template<typename T>
	void InsertEvent(T* Event, EENM_EventSide Side, uint32 Identifier);

	template<typename T>
	void ExecuteEvent(T* Event, EENM_EventSide Side, uint32 Identifier);

	template<typename T>
	void ImmediateDispatchEvent(T* Event, uint32 Identifier);
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

protected:
	void QueueDispatchEvent(FName Name, FEventBase* Event, uint32 Identifier);
	void FlushEvent();

	void ClientEventQueue();
	void ServerEventQueue();



private:
	virtual void Tick(float DeltaTime) override;

	virtual bool IsTickable() const override
	{
		return true;
	}
	virtual bool IsTickableWhenPaused() const override
	{
		return true;
	}
	virtual bool IsTickableInEditor() const override
	{
		return false;
	}
	virtual TStatId GetStatId() const override
	{
		return TStatId();
	}

private_subobject:
	UPROPERTY()
	class UEGameInstance* GameInstance;

protected:
	EventsQueue ClientEventPriorityQueue;
	EventIdentifierQueue ClientEventIdQueue;

	EventsQueue ServerEventPriorityQueue;
	EventIdentifierQueue ServerEventIdQueue;

	EventContainer EventMap;

};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template<typename T>
void UEEventDispatcher::InsertEvent(T* Event, EENM_EventSide Side, uint32 Identifier)
{
	if (!Event) return;

	switch (Side)
	{
	case EENM_EventSide::ClientToClient:
	case EENM_EventSide::ServerToClient:
	{
		if (GIsEditor)
		{
			if (ENetMode::NM_Client == GameInstance->GetWorld()->GetNetMode() || ENetMode::NM_Standalone == GameInstance->GetWorld()->GetNetMode())
			{
				ExecuteEvent(Event, Side, Identifier);
			}
		}
		else
		{
			if (IsRunningGame())
			{
				ExecuteEvent(Event, Side, Identifier);
			}
		}
	}
	break;

	case EENM_EventSide::ServerToServer:
	case EENM_EventSide::ClientToServer:
	{
		if (GIsEditor)
		{
			if (ENetMode::NM_DedicatedServer == GameInstance->GetWorld()->GetNetMode() || ENetMode::NM_Standalone == GameInstance->GetWorld()->GetNetMode())
			{
				ExecuteEvent(Event, Side, Identifier);
			}
		}
		else
		{
			if (IsRunningDedicatedServer())
			{
				ExecuteEvent(Event, Side, Identifier);
			}
		}
	}
	break;

	default:
		break;
	}
}

template<typename T>
void UEEventDispatcher::ExecuteEvent(T* Event, EENM_EventSide Side, uint32 Identifier)
{
	if (!Event) return;

	FEventBase* EventBase = static_cast<FEventBase*>(Event);
	if (EventBase)
	{
		if (EENM_EventPriority::Immediate == EventBase->GetPriority())
		{
			ImmediateDispatchEvent(Event, Identifier);
			return;
		}
		else
		{
			switch (Side)
			{
			case EENM_EventSide::ClientToClient:
			case EENM_EventSide::ServerToClient:
				ClientEventPriorityQueue.Add(EventBase);
				ClientEventIdQueue.Add(Identifier);
				break;

			case EENM_EventSide::ServerToServer:
			case EENM_EventSide::ClientToServer:
				ServerEventPriorityQueue.Add(EventBase);
				ServerEventIdQueue.Add(Identifier);
				break;
			}
		}
	}
}

template<typename T>
void UEEventDispatcher::ImmediateDispatchEvent(T* Event, uint32 Identifier)
{
	if (!Event) return;

	FName EventName = Event->GetTypeName();

	EventObject* Events = EventTestMap.FindRef(EventName);
	if (Events)
	{
		for (FEventHandlerBase* Base : *Events)
		{
			if (Base)
			{
				FEventHandlerModify<T>* EventMod = static_cast<FEventHandlerModify<T>*>(Base);
				if (EventMod)
				{
					if (0 == Identifier)
					{
						Base->Execute((void*)Event);
					}
					else
					{
						if (Identifier == EventMod->GetTargetEventIdentify())
						{
							Base->Execute((void*)Event);
						}
					}
				}
			}
		}
	}
}
//#endif //EVENT_HANDLER
