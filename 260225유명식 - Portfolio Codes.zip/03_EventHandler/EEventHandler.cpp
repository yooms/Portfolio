// Fill out your copyright notice in the Description page of Project Settings.

#include "Ember.h"

//#ifdef EVENT_HANDLER
UEEventHandler::UEEventHandler(const class FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UEEventHandler::~UEEventHandler()
{
}

void UEEventHandler::ManagerInit(class UEGameInstance* InGameInstance)
{
	EventDispatcher = NewObject<UEEventDispatcher>();
	if (EventDispatcher && EventDispatcher->IsValidLowLevel())
	{
		EventDispatcher->SetGameInstance(InGameInstance);
	}
}
//#endif //EVENT_HANDLER